# Leon the Dino 🦖 — floating offline assistant for Android

Leon floats over your home screen and every app, wanders, sleeps, gets bored, touches (reads) text, cries when muted,
and chats using **his own offline AI** (no internet permission, no API, no cloud).
Art = your two character sheets, cut into 10 full-body poses + 25 reaction stickers.

```
LeonDino/
  app/                         the Android app (Kotlin, ZERO third-party libraries)
    src/main/java/com/leon/dino/
      LeonOverlayService.kt    foreground service, the 2 overlay windows, touch, frame loop, notification
      LeonBehavior.kt          Leon's life: walk / sleep / boredom / touch text / mute breakdown (small scripts)
      FxView.kt                bubbles, typed notes, the text card in his hands, throw animation, Zzz/tears/hearts
      LeonView.kt              the touchable body sprite (squash & stretch, tilt)
      ScreenReaderService.kt   READ-ONLY accessibility service (keyboard position, button bounds, one text read)
      MainActivity.kt / ChatActivity.kt   setup + settings, and the pop-up chat window
      brain/                   Leon's offline AI (self-contained, reusable in other apps)
    src/main/assets/           leon/ (35 PNG sprites), leon_model.json (trained model), leon_content.json (phrasebook)
  ai/                          train & test the AI with no internet: leon_intents.txt, leon_content.py,
                               train_leon_model.py, chat_cli.py (talk to Leon in a terminal)
  tools/make_sprites.py        re-cut sprites from the character sheets
  .github/workflows/build-apk.yml + ci/build.sh   cloud build that produces the APK
  docs/BUILD_APK_FROM_PHONE.md      step-by-step, phone only
```

## Get the APK (no computer needed)
This project includes a cloud build (`.github/workflows/build-apk.yml`). Follow **docs/BUILD_APK_FROM_PHONE.md**: upload the zip to a free
GitHub repo, add the workflow file, wait ~8 minutes, download `Leon-the-Dino.apk`, install. Every build is signed with the same key, so updates install over the old app.

## Build and run on a computer
1. Android Studio (Koala or newer), JDK 17, Android SDK platform **34**. `File > Open > LeonDino`.
2. First Gradle sync fetches only the Android + Kotlin Gradle plugins (the app itself has no libraries, so there is nothing else
   to download). If your PC is fully offline, sync once with internet or use a machine that already has AGP 8.5.2 / Kotlin 1.9.24 / Gradle 8.7 cached.
   If the IDE offers "Upgrade AGP", accepting is safe.
3. Run on a **real phone** (Android 8.0+). Overlays are unreliable on emulators.
4. In the app: **1** Allow floating over other apps · **2** Enable "Leon (read-only text touch)" in Accessibility · tap **Wake Leon up!**
   - Sideloaded APK on Android 13+ and the accessibility switch is greyed out: *Settings > Apps > Leon > ⋮ > Allow restricted settings*.
   - Xiaomi / Oppo / Vivo / Realme / Samsung: also allow "Display pop-up windows while running in background" and set battery to *Unrestricted*, or the system kills him.

## What he does (your spec → where it lives)
| Spec | Behaviour |
|---|---|
| Floats anywhere on screen | 2 overlay windows; wanders inside the safe area; drag him to carry him |
| Sleep | 5-min nap after every 6 h awake; deep sleep **12 AM–5 AM** (no movement, no sound, 60% size, 35% opacity, not touchable); wakes at 5 AM (all adjustable) |
| Touches all text, can't change it | Walks to a text element, reads that ONE string, shows it on a card in his hands. Never types/edits/clicks (the accessibility config doesn't even request those abilities). Not copied to the clipboard. |
| Bored → grabs text → throws it "like nothing" | After 15 idle min (adjustable): boredom stages 1-5 (commentary, fact, quote spam, pacing, **scream**) then the card flies off, spins, bursts into paper bits and the text is destroyed |
| Keyboard / bar avoidance | Detects the keyboard through the accessibility window list, steps above it, fades to 20% and lets touches pass; stays inside status/nav bars; walks around buttons seen in the last scan |
| Battery | 30 fps only while moving/talking, 10 fps when idle or napping, 2 fps in deep sleep, loop paused when the screen is off; no continuous scanning (bounds-only scan at most every 5 s, text only on touch) |
| Mute button trait | Long-press Leon / notification button / chat "mute": confusion → bargaining → begging-and-crying → typed notes. "Leon, I need silence for real, not joke" = one last sob, then total respect. Unmute: he asks first ("volume 3 lang"), then quote + joke + tiny sorry. |
| Personality | yarn endings, po/opo, Taglish, r-curses only as exclamations at things (never in sad/serious moods, never with "clean mode"), read-the-room (comfort first, jokes only when invited), math & science lens |

Controls: drag = carry · tap = poke · **double-tap = chat** · **long-press = mute/unmute**.

## Privacy and safety
- No `INTERNET` permission. Nothing is sent anywhere. Chats and memories stay in the app's private storage.
- Held text lives in a `CharArray` in RAM and is zero-filled when set down, thrown, interrupted, or when the screen turns off. Nothing is logged.
- Always skipped: password fields, text boxes with PIN/OTP/CVV-type hints, Leon's own windows, and apps in the block list (password managers/authenticators by default; add your bank app in Settings). Text boxes you type in are **off by default** (switch in Settings).
- Crisis wording ("I want to die", etc.) bypasses all jokes and shows care + the Philippine NCMH hotline (1553; 0919-057-1553; 0917-899-8727; 911). Numbers live in `ai/leon_content.py` -> `CRISIS`; check them for your country.

## His AI ("own model", honestly)
Not an LLM. It is a small **trained intent model** (averaged perceptron on words + word pairs + character trigrams, ~200 KB) plus
keyword rules, a phrasebook, an offline calculator (12*7, sqrt(144), 15% of 2000, "hatian 1250 sa 4"), memory (your name / favourite food)
and the character-bible style rules. Fast, tiny, 100% offline, always in character, but it can only talk about what is in its book.
Measured here: model alone 52% on strictly held-out phrases (small dataset); rules + model 95% on the training phrases. More phrases in
`ai/leon_intents.txt` + `python3 ai/train_leon_model.py` = smarter Leon, no internet needed. Test without the phone: `python3 ai/chat_cli.py`.

## Troubleshooting
- **He doesn't appear** → step 1 not granted, or the OEM pop-up/battery permission above.
- **Apps below him won't take touches (Android 12+)** → keep the fx window alpha ≤ 0.8 (it is 0.79). Don't raise it.
- **No keyboard avoidance / no text touching** → the accessibility service is off; Leon still wanders, sleeps and chats.
- **No voice** → Settings > Leon's voice, and install an offline text-to-speech voice in the phone's TTS settings.
- **Build error** → send me the exact message. I could not compile Kotlin in my sandbox (no Android SDK/compiler there); I reviewed every file by hand, ran the Python brain/trainer/sprite tool for real, and checked cross-file names with scripts.
- Lip-sync note: flat sheet art can't swap mouth shapes, so talking = syllable-timed bounce + happy/excited face swaps + a wiggle on every "yarn". The mouth charts are not used by the app (they suit a Live2D rig later).
