# Leon's offline AI pack (no API, no internet)

Files
- `leon_intents.txt`   training phrases per intent (edit, add Taglish phrases)
- `leon_content.py`    EVERYTHING Leon can say: quotes, jokes, facts, science topics, replies, boredom/mute/sleep lines, crisis text, keyword rules
- `train_leon_model.py` trains `leon_model.json` (+ writes `leon_content.json`). Pure Python 3, no libraries: `python3 train_leon_model.py`
- `chat_cli.py`        talk to Leon in a terminal using the exact same logic as the app: `python3 chat_cli.py` (or `--demo`)
- Android side: `brain/*.kt` (copy the folder into any app) + the two JSON files in `assets/`

Use it in another Android app
```kotlin
val leon = LeonBrain(context)               // loads assets/leon_model.json + assets/leon_content.json
val r = leon.reply("pagod na ako po")        // r.lines  : List<String> to show/speak
                                             // r.mood   : "sad" | "happy" | ...   (10 body poses)
                                             // r.emote  : "tired" | "laughing" ... (25 stickers) or null
                                             // r.action : NONE | MUTE | UNMUTE | SILENCE_REAL | CHATTY_DOWN (you perform it)
leon.quote(); leon.joke(); leon.fact()       // for ambient chatter
leon.cleanMode = true                        // no curse words
```
Pipeline: crisis check → "silence for real" fail-safe → pending question → remember name/food → calculator → yes/no → keyword rules → trained model → template + slots → voice rules (yarn, po/opo, curse gating, read-the-room).

Retrain: edit phrases/replies → `python3 train_leon_model.py` → copy the two JSONs into `app/src/main/assets/` (the script already writes them there when run inside the project).
Tokenizer/feature code is duplicated in `train_leon_model.py` and `brain/IntentModel.kt` and must stay identical.

Limits: no open-ended generation, no knowledge beyond the phrasebook, no internet facts. Held-out accuracy of the model alone ≈ 52% on 566 short phrases;
the keyword rules in front of it carry the common cases. Growing the dataset is the way to improve it.
