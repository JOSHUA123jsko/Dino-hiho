#!/usr/bin/env python3
"""
Talk to Leon in your terminal -- same model, same phrasebook, same rules as the Android app (offline, no internet).
  python3 chat_cli.py            interactive
  python3 chat_cli.py --demo     run a built-in demo conversation
This is a line-for-line Python mirror of app/.../brain/LeonBrain.kt, handy for testing new phrases and
phrasebook edits without building the app. After editing leon_intents.txt / leon_content.py run train_leon_model.py.
"""
import json, math, os, random, re, sys, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from train_leon_model import tokens, features, softmax

ASSETS = os.path.join(HERE, '..', 'app', 'src', 'main', 'assets')
MODEL = json.load(open(os.path.join(ASSETS, 'leon_model.json'), encoding='utf-8'))
C = json.load(open(os.path.join(ASSETS, 'leon_content.json'), encoding='utf-8'))
W = {f: {c: w for c, w in row} for f, row in MODEL['feat'].items()}
CLASSES = MODEL['classes']

# ------------------------------------------------------------ math (mirror of MathSolver.kt)
class MathError(Exception): pass
class DivZero(Exception): pass

class Parser:
    def __init__(self, s): self.s, self.pos = s, 0
    def peek(self): return self.s[self.pos] if self.pos < len(self.s) else '\0'
    def ws(self):
        while self.pos < len(self.s) and self.s[self.pos] == ' ': self.pos += 1
    def parse(self):
        v = self.expr(); self.ws()
        if self.pos != len(self.s): raise MathError('trailing')
        return v
    def expr(self):
        v = self.term()
        while True:
            self.ws(); c = self.peek()
            if c == '+': self.pos += 1; v += self.term()
            elif c == '-': self.pos += 1; v -= self.term()
            else: return v
    def term(self):
        v = self.unary()
        while True:
            self.ws(); c = self.peek()
            if c == '*': self.pos += 1; v *= self.unary()
            elif c == '/':
                self.pos += 1; d = self.unary()
                if d == 0: raise DivZero()
                v /= d
            else: return v
    def unary(self):
        self.ws(); c = self.peek()
        if c == '-': self.pos += 1; return -self.unary()
        if c == '+': self.pos += 1; return self.unary()
        return self.power()
    def power(self):
        b = self.postfix(); self.ws()
        if self.peek() == '^': self.pos += 1; return b ** self.unary()
        return b
    def postfix(self):
        v = self.primary()
        while True:
            self.ws()
            if self.peek() == '!': self.pos += 1; v = self.fact(v)
            else: return v
    def primary(self):
        self.ws(); c = self.peek()
        if c == '(':
            self.pos += 1; v = self.expr(); self.ws()
            if self.peek() != ')': raise MathError('paren')
            self.pos += 1; return v
        if c.isdigit() or c == '.': return self.number()
        if c.isalpha():
            name = self.ident(); self.ws()
            if self.peek() == '(':
                self.pos += 1; a = self.expr(); self.ws()
                if self.peek() != ')': raise MathError('paren')
                self.pos += 1; return self.call(name, a)
            if name == 'pi': return math.pi
            if name == 'e': return math.e
            raise MathError('unknown ' + name)
        raise MathError('unexpected')
    def number(self):
        st = self.pos
        while self.pos < len(self.s) and (self.s[self.pos].isdigit() or self.s[self.pos] == '.'): self.pos += 1
        return float(self.s[st:self.pos])
    def ident(self):
        st = self.pos
        while self.pos < len(self.s) and self.s[self.pos].isalnum(): self.pos += 1
        return self.s[st:self.pos]
    def fact(self, v):
        if v < 0 or v != math.floor(v) or v > 100: raise MathError('fact')
        return float(math.factorial(int(v)))
    def call(self, n, a):
        f = {'sqrt': lambda: math.sqrt(a) if a >= 0 else (_ for _ in ()).throw(MathError('sqrt')), 'abs': lambda: abs(a), 'sin': lambda: math.sin(a), 'cos': lambda: math.cos(a),
             'tan': lambda: math.tan(a), 'ln': lambda: math.log(a), 'log': lambda: math.log10(a), 'log2': lambda: math.log2(a), 'exp': lambda: math.exp(a),
             'floor': lambda: math.floor(a), 'ceil': lambda: math.ceil(a), 'round': lambda: round(a), 'fact': lambda: self.fact(a)}.get(n)
        if not f: raise MathError('func')
        return float(f())

def fmt(d):
    if math.isnan(d) or math.isinf(d): return 'hindi ma-compute'
    if abs(d) >= 1e15 or (abs(d) < 1e-6 and d != 0): return '%.4e' % d
    s = ('%.6f' % d).rstrip('0').rstrip('.')
    return s or '0'

PCT = re.compile(r'(\d+(?:\.\d+)?)\s*%\s*(?:of|ng)\s*(\d+(?:\.\d+)?)')
SPLIT = re.compile(r'(?:hati(?:an)?|split|divide)\D{0,20}?(\d+(?:\.\d+)?)\D{1,15}?(\d+)\b')
DATE = re.compile(r'\d{1,4}\s*-\s*\d{1,2}\s*-\s*\d{1,4}')
FUNC = re.compile(r'(sqrt|abs|sin|cos|tan|asin|acos|atan|ln|log|log2|exp|floor|ceil|round|fact)\s*\(')

def mathy(s):
    if not any(ch.isdigit() for ch in s): return False
    if FUNC.search(s): return True
    if any(ch in s for ch in '*/^+!'): return True
    return ' - ' in s

def detect_math(raw):
    t = re.sub(r'(?<=\d),(?=\d{3})', '', raw.lower())
    m = PCT.search(t)
    if m: p, o = float(m[1]), float(m[2]); return ('percent', p / 100 * o)
    m = SPLIT.search(t)
    if m:
        n = int(m[2])
        return ('div0', 0) if n == 0 else ('split', float(m[1]) / n)
    mf = re.search(r'(?:factorial of|factorial ng)\s*(\d+)|(\d+)\s*factorial', t)
    if mf:
        n = int(mf[1] or mf[2])
        if 0 <= n <= 100: return ('calc', float(math.factorial(n)), f'{n}!')
    p = t.replace('×', '*').replace('÷', '/').replace('**', '^')
    p = re.sub(r'(?<=\d)\s*x\s*(?=\d)', '*', p)
    if DATE.search(p): return None
    words = p.split()
    for i in range(len(words)):
        for j in range(len(words), i, -1):
            cand = ' '.join(words[i:j]).rstrip('?.,=').strip()
            if cand.endswith('!') and not re.fullmatch(r'\(?\d+\)?!+', cand): cand = cand.rstrip('!')
            if not mathy(cand): continue
            try: return ('calc', Parser(cand).parse(), cand)
            except DivZero: return ('div0', 0)
            except Exception: pass
    return None

# ------------------------------------------------------------ brain (mirror of LeonBrain.kt)
LOOK = {'greet': ('happy', 'cheerful'), 'bye': ('shy', 'goodbye'), 'goodnight': ('sleepy', 'sleepy'), 'how_are_you': ('happy', 'cheerful'),
        'who_are_you': ('happy', 'proud'), 'ai_question': ('thinking', 'cool'), 'thanks': ('love', 'love'), 'sorry': ('shy', 'embarrassed'),
        'praise': ('love', 'kiss'), 'tease': ('pouty', 'pouty'), 'noisy': ('shy', 'embarrassed'), 'sad': ('sad', 'sad'), 'lonely': ('sad', 'hurt'),
        'tired': ('sleepy', 'tired'), 'stressed': ('thinking', 'scared'), 'angry': ('thinking', 'hurt'), 'bored': ('pouty', 'pouty'),
        'happy_share': ('excited', 'excited'), 'joke': ('excited', 'laughing'), 'quote': ('thinking', 'proud'), 'fact': ('thinking', 'surprised'),
        'explain': ('thinking', 'thinking'), 'math_help': ('thinking', 'cool'), 'food': ('excited', 'hungry'), 'time': ('happy', 'wink'),
        'date': ('happy', 'wink'), 'sleep_info': ('sleepy', 'sleepy'), 'help': ('happy', 'cheerful'), 'chat_prompt': ('happy', 'wink'),
        'affirm': ('excited', 'cheerful'), 'deny': ('shy', None), 'unknown': ('thinking', 'confused')}

class Brain:
    def __init__(self):
        self.polite = 0; self.trust = 0; self.name = ''; self.food = ''; self.awaiting = None; self.clean = False
        self.recent = {}

    def pick(self, key, pool, ok=lambda t: True):
        idx = [i for i, t in enumerate(pool) if ok(t)]
        if not idx: return None
        hist = self.recent.setdefault(key, [])
        c = [i for i in idx if i not in hist] or idx
        if len(c) == len(idx) and hist: hist.clear()
        i = random.choice(c); hist.append(i)
        while len(hist) > min(4, len(idx) // 2): hist.pop(0)
        return pool[i]

    def block(self, serious): return serious or self.clean or self.polite > 0
    def has_curse(self, t): return any(c in t.lower() for c in C['curses'])
    def sanitize(self, s):
        for c in C['curses']: s = re.sub(re.escape(c), lambda m: 'Naku' if m[0][0].isupper() else 'naku', s, flags=re.I)
        return s
    def finish(self, s, serious=False):
        s = re.sub(r'\s{2,}', ' ', s).replace(' ,', ',').strip()
        if self.block(serious): s = self.sanitize(s)
        return yarn(s)
    def tpl(self, key, pool, serious):
        blk = self.block(serious); trusted = self.trust >= 6
        r = self.pick(key, pool, lambda t: (trusted or not t.startswith('[trust]')) and (not blk or not self.has_curse(t)))
        if r is None: r = self.pick(key, pool, lambda t: trusted or not t.startswith('[trust]'))
        return None if r is None else r.removeprefix('[trust]').removeprefix('!c')
    def quote(self): return self.pick('q', C['quotes'])
    def joke(self): return self.pick('j', C['jokes'])
    def fact(self): return self.pick('f', C['facts'])
    def render(self, t, extra=None):
        for k, v in (extra or {}).items(): t = t.replace('{%s}' % k, v)
        h = datetime.datetime.now().hour
        tod = 'morning' if 5 <= h <= 10 else 'noon' if h <= 12 and h >= 11 else 'afternoon' if 13 <= h <= 17 else 'evening' if h >= 18 else 'late'
        reps = {'po': lambda: ' po' if self.polite else '', 'Opo': lambda: 'Opo' if self.polite else 'Oo',
                'name': lambda: self.name or self.pick('n', C['nicknames']), 'tod': lambda: C['tod'][tod],
                'quote': self.quote, 'joke': self.joke, 'fact': self.fact,
                'food': lambda: self.food if self.food and random.random() < .4 else self.pick('fd', C['foods']),
                'time': lambda: datetime.datetime.now().strftime('%I:%M %p').lstrip('0'),
                'date': lambda: datetime.datetime.now().strftime('%A, %B %d, %Y')}
        for k, f in reps.items():
            if '{%s}' % k in t: t = t.replace('{%s}' % k, f())
        return re.sub(r'\{[A-Za-z]+\}', '', t)

    def say(self, intent, extra=None, action=None):
        mood, emote = LOOK.get(intent, ('happy', None)); serious = intent in C['serious']
        t = self.tpl('rep:' + intent, C['replies'].get(intent, []), serious)
        if t is None: return self.say('unknown') if intent != 'unknown' else ([], mood, emote, action)
        return ([self.finish(self.render(t, extra), serious)], mood, emote, action)

    def topic(self, joined):
        pad = ' ' + joined + ' '
        for t in C['topics']:
            for k in t['keys']:
                kk = ' '.join(tokens(k))
                if kk and (' ' + kk + ' ') in pad: return t
        return None

    def rule(self, toks, joined):
        pad = ' ' + joined + ' '
        for intent, kws in C['rules']:
            for kw in kws:
                if kw.endswith('*'):
                    if any(t.startswith(kw[:-1]) for t in toks): return intent
                else:
                    k = ' '.join(tokens(kw))
                    if not k: continue
                    if ' ' in k:
                        if (' ' + k + ' ') in pad: return intent
                    elif k in toks: return intent
        return 'explain' if self.topic(joined) else None

    def classify(self, text):
        fs = features(text)
        if not fs: return 'unknown'
        n = 1 / math.sqrt(len(fs)); sc = [0.0] * len(CLASSES)
        for f in fs:
            for c, w in W.get(f, {}).items(): sc[c] += w * n
        p = softmax(sc, MODEL['tau']); i = max(range(len(p)), key=p.__getitem__)
        return CLASSES[i] if p[i] >= MODEL['threshold'] else 'unknown'

    def reply(self, raw):
        text = raw.strip(); lower = text.lower(); toks = tokens(text); joined = ' '.join(toks)
        if any(t in C['polite_markers'] for t in toks): self.polite = 6
        elif self.polite: self.polite -= 1
        self.trust = min(20, self.trust + 1)
        if any(p in lower for p in C['crisis_patterns']): return (C['crisis'], 'sad', 'hurt', None)
        if any(p in lower for p in C['silence_patterns']): return ([], 'sad', 'sad', 'SILENCE_REAL')
        if self.awaiting:
            self.awaiting = None
            for kws, key in ((('comfort', 'makinig', 'samahan', 'yakap', 'listen'), 'choice_comfort'),
                             (('explain', 'ipaliwanag', 'advice', 'solution', 'tips', 'dahilan'), 'choice_explain'),
                             (('joke', 'patawa', 'patawanin', 'distract'), 'choice_joke')):
                if any(k in joined for k in kws): return self.say(key)
        m = re.search(r"(?:my name is|call me|ako si|tawagin mo akong|pangalan ko ay|pangalan ko si)\s+([a-zñ][a-zñ'\-]{1,14})", lower)
        if m and m[1] not in ('leon', 'dino', 'si', 'ang', 'po', 'na', 'ay'):
            self.name = m[1].title(); return ([self.finish(self.render(self.pick('mn', C['memory']['name_set'])))], 'happy', 'cheerful', None)
        mf = re.search(r"(?:paborito ko ang|paborito ko ay|paborito ko|favorite food is|my favorite food is|favorite ko ang)\s+([a-zñ\-]{2,15}(?: [a-zñ\-]{2,15})?)", lower)
        if mf: self.food = mf[1]; return ([self.finish(self.render(self.pick('mf', C['memory']['food_set']), {'food': mf[1]}))], 'excited', 'hungry', None)
        d = detect_math(text)
        if d:
            kind = d[0]
            if kind == 'calc': t = self.pick('mc', C['math']['result']).replace('{x}', d[2]).replace('{result}', fmt(d[1]))
            elif kind == 'percent': t = self.pick('mp', C['math']['percent']).replace('{result}', fmt(d[1]))
            elif kind == 'split': t = self.pick('ms', C['math']['split']).replace('{result}', fmt(d[1]))
            else: t = self.pick('md', C['math']['div0'])
            return ([self.finish(t)], 'thinking', 'cool', None)
        core = ' '.join(t for t in toks if t not in C['filler'])
        if core in C['affirm']: return self.say('affirm')
        if core in C['deny']: return self.say('deny')
        intent = self.rule(toks, joined) or self.classify(text)
        if intent == 'mute_playful': return ([], 'sad', 'begging', 'MUTE')
        if intent == 'unmute': return ([], 'shy', 'kiss', 'UNMUTE')
        if intent == 'noisy': return self.say('noisy', action='CHATTY_DOWN')
        if intent == 'explain':
            t = self.topic(joined)
            return ([self.finish(t['text'])], 'thinking', 'thinking', None) if t else self.say('unknown')
        if intent in ('sad', 'lonely'):
            lines, mood, emote, a = self.say(intent)
            f = self.pick('fc', C['follow_comfort']); self.awaiting = 'comfort'
            return (lines + [self.finish(f, True)], mood, emote, a)
        if intent in ('tired', 'stressed'):
            return self.say(intent, {'tip': self.pick('tip' + intent, C['tips'][intent]) or ''})
        return self.say(intent)

def yarn(l):
    l = l.strip()
    if not l or 'yarn' in l.lower(): return l
    if l[0] in '(*[:': return l
    if not any(ch.islower() for ch in l): return l
    e = len(l)
    while e > 0 and l[e - 1] in '.!?…': e -= 1
    return l[:e] + ', yarn' + l[e:]

DEMO = ["hi leon!", "kumusta po", "pagod na ako", "stressed ako sa exam bukas", "malungkot ako", "comfort lang", "tell me a joke", "gusto ko ng quote",
        "explain gravity", "bakit asul ang langit", "what is 12*7", "sqrt(144) + 2^3", "15% of 2000", "hatian 1250 sa 4", "10/0", "5!",
        "ako si Ana", "paborito ko ang sinigang", "gutom ako", "anong oras na", "ang ingay mo", "Leon, I need silence for real, not joke",
        "i-mute kita", "unmute", "robot ka ba?", "ano kaya mong gawin", "bored ako", "sino ka", "magkano ang load", "i want to kill myself"]

if __name__ == '__main__':
    b = Brain()
    if '--demo' in sys.argv:
        for q in DEMO:
            lines, mood, emote, act = b.reply(q)
            print(f'\nYOU : {q}\nLEON: [{mood}/{emote}{"/" + act if act else ""}]')
            for ln in lines: print('      ' + ln)
    else:
        print('Leon (offline). Type "quit" to leave.')
        while True:
            try: q = input('you > ')
            except EOFError: break
            if q.strip().lower() in ('quit', 'exit'): break
            lines, mood, emote, act = b.reply(q)
            print(f'leon [{mood}/{emote}{"/" + act if act else ""}]')
            for ln in lines: print('  ' + ln)
