#!/usr/bin/env python3
"""
Leon's own model -- trained 100% offline, pure Python (no libraries, no API).

  python3 train_leon_model.py

Reads  leon_intents.txt   (edit it to teach Leon new phrases)
       leon_content.py    (his phrasebook; edit it to change what he says)
Writes ../app/src/main/assets/leon_model.json    (intent classifier, ~100 KB)
       ../app/src/main/assets/leon_content.json  (phrasebook)

Model = averaged perceptron over word unigrams + word bigrams + char trigrams
(char trigrams make it forgiving about Taglish spelling and typos).
The Kotlin side (brain/IntentModel.kt) uses the exact same tokenizer + features.
"""
import json, math, os, random, sys
from collections import defaultdict, Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', 'app', 'src', 'main', 'assets')
random.seed(7)

# ---------- tokenizer + features (MUST match IntentModel.kt) ----------
def tokens(text):
    s = ''.join(ch if ch.isalnum() else ' ' for ch in text.lower())
    return s.split()

def features(text):
    toks = tokens(text)
    f = set()
    for t in toks:
        f.add('w:' + t)
        p = '^' + t + '$'
        if len(t) >= 3:
            for i in range(len(p) - 2):
                f.add('c:' + p[i:i+3])
    for a, b in zip(toks, toks[1:]):
        f.add('b:' + a + '_' + b)
    return f

# ---------- data ----------
def load_seeds(path):
    data, cur = defaultdict(list), None
    for line in open(path, encoding='utf-8'):
        line = line.strip()
        if not line or line.startswith('#') and not line.startswith('##'):
            continue
        if line.startswith('## '):
            cur = line[3:].strip(); continue
        if cur: data[cur].append(line)
    return data

def augment(text):
    out = [text]
    toks = text.split()
    if 'po' not in toks: out.append(text + ' po')
    out.append('leon ' + text)
    out.append(text + ' yarn')
    cand = [i for i, t in enumerate(toks) if len(t) >= 4]
    if cand:
        i = random.choice(cand); t = toks[i]; j = random.randrange(1, len(t) - 1)
        out.append(' '.join(toks[:i] + [t[:j] + t[j+1:]] + toks[i+1:]))
    return out

def train(data, epochs=10, aug=True, seed=11):
    """Averaged multiclass perceptron on L2-normalised binary features. Returns (classes, weights)."""
    rnd = random.Random(seed)
    classes = sorted(data); ci = {c: i for i, c in enumerate(classes)}
    docs = []
    for c in classes:
        for s in data[c]:
            for v in (augment(s) if aug else [s]):
                fs = sorted(features(v))
                if fs: docs.append((fs, ci[c]))
    W, T, t = {}, {}, 1
    for _ in range(epochs):
        rnd.shuffle(docs)
        for fs, y in docs:
            n = 1.0 / math.sqrt(len(fs))
            sc = {}
            for f in fs:
                row = W.get(f)
                if row:
                    for c, w in row.items(): sc[c] = sc.get(c, 0.0) + w * n
            pred = max(sc, key=sc.get) if sc else -1
            if pred != y:
                for f in fs:
                    row = W.setdefault(f, {}); tr = T.setdefault(f, {})
                    row[y] = row.get(y, 0.0) + n; tr[y] = tr.get(y, 0.0) + t * n
                    if pred >= 0:
                        row[pred] = row.get(pred, 0.0) - n; tr[pred] = tr.get(pred, 0.0) - t * n
            t += 1
    avg = {}
    for f, row in W.items():
        tr = T.get(f, {})
        r = {c: w - tr.get(c, 0.0) / t for c, w in row.items()}
        r = {c: v for c, v in r.items() if abs(v) > 0.02}
        if r: avg[f] = r
    return classes, avg

def score(feats, classes, W):
    fs = [f for f in feats]
    n = 1.0 / math.sqrt(max(1, len(fs)))
    out = [0.0] * len(classes)
    for f in fs:
        row = W.get(f)
        if row:
            for c, w in row.items(): out[c] += w * n
    return out

def softmax(scores, tau):
    m = max(scores); e = [math.exp((s - m) / tau) for s in scores]; z = sum(e)
    return [x / z for x in e]

def crossval(data, k=5):
    items = [(c, s) for c, ss in data.items() for s in ss]
    random.shuffle(items)
    folds = [items[i::k] for i in range(k)]
    results = []
    for i in range(k):
        train_d = defaultdict(list)
        for j, fold in enumerate(folds):
            if j != i:
                for c, s in fold: train_d[c].append(s)
        classes, W = train(dict(train_d))
        full = sorted(data)
        for c, s in folds[i]:
            sc = score(features(s), classes, W)
            results.append((c, sc, classes))
    return results

def tune(results):
    best = None
    for tau in (0.1, 0.2, 0.3):
        for th in (0.5, 0.6, 0.7, 0.8):
            ok = 0
            for true, sc, classes in results:
                p = softmax(sc, tau); i = max(range(len(p)), key=p.__getitem__)
                pred = classes[i] if p[i] >= th else 'unknown'
                ok += (pred == true)
            acc = ok / len(results)
            if best is None or acc > best[0] + 1e-9: best = (acc, tau, th)
    return best

sys.path.insert(0, HERE)

def main():
    data = load_seeds(os.path.join(HERE, 'leon_intents.txt'))
    n = sum(len(v) for v in data.values())
    print(f'{len(data)} intents, {n} seed phrases')
    res = crossval(data)
    top1 = sum(1 for t, sc, cl in res if cl[max(range(len(sc)), key=sc.__getitem__)] == t) / len(res)
    acc, tau, th = tune(res)
    print(f'5-fold held-out accuracy: argmax {top1:.1%}; with abstain threshold {acc:.1%} (tau={tau}, th={th})')

    classes, W = train(data)
    # hybrid check (same logic the app runs): keyword rules first, trained model second
    import leon_content as LC
    def rule_match(text):
        toks = tokens(text); joined = ' '.join(toks)
        for intent, kws in LC.RULES:
            for kw in kws:
                k = ' '.join(tokens(kw)) if not kw.endswith('*') else kw
                if kw.endswith('*'):
                    if any(t.startswith(kw[:-1]) for t in toks): return intent
                elif ' ' in k:
                    if (' ' + k + ' ') in (' ' + joined + ' '): return intent
                elif k in toks: return intent
        return None
    ok = 0; tot = 0
    for c, ss in data.items():
        for x in ss:
            r = rule_match(x)
            if r is None:
                sc = score(features(x), classes, W); p_ = softmax(sc, tau); i = max(range(len(p_)), key=p_.__getitem__)
                r = classes[i] if p_[i] >= th else 'unknown'
            ok += (r == c); tot += 1
    print(f'hybrid (rules+model) accuracy on all seeds (in-sample): {ok/tot:.1%}')
    feat = {f: [[c, round(w, 3)] for c, w in sorted(row.items())] for f, row in W.items()}
    model = {'version': 2, 'type': 'averaged_perceptron_sparse', 'classes': classes,
             'tau': tau, 'threshold': th, 'unknown_class': 'unknown', 'feat': feat}
    os.makedirs(ASSETS, exist_ok=True)
    out = os.path.join(ASSETS, 'leon_model.json')
    json.dump(model, open(out, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(f'wrote {out}  ({os.path.getsize(out)/1024:.0f} KB, {len(feat)} features)')

    cj = os.path.join(ASSETS, 'leon_content.json')
    json.dump(LC.CONTENT, open(cj, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'wrote {cj}  ({os.path.getsize(cj)/1024:.0f} KB)')

if __name__ == '__main__':
    main()
