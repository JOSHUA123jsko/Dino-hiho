plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.leon.dino"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.leon.dino"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // One fixed signing key for every build (debug AND release), so a new build installs OVER the old one
    // and keeps your permissions. Personal-use key: do not publish to Google Play with it.
    signingConfigs {
        create("leon") {
            storeFile = file("leon-debug.keystore")
            storePassword = "leonleon"
            keyAlias = "leon"
            keyPassword = "leonleon"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("leon")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("leon")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// ZERO third-party libraries on purpose (no androidx, no ML kit, no network SDKs):
// the only things Gradle has to fetch are the Android + Kotlin plugins themselves.
dependencies {
}
