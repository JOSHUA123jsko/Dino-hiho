package com.leon.dino

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Starts Leon after reboot, only if you switched "Start when phone turns on" on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Prefs(context).autostart && Settings.canDrawOverlays(context)) {
            try {
                LeonOverlayService.start(context)
            } catch (e: Exception) {
                // some phones block this until the app is opened once; harmless
            }
        }
    }
}
