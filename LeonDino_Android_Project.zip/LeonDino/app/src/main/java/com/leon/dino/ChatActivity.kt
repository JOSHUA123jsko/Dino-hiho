package com.leon.dino

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.leon.dino.brain.Action
import com.leon.dino.brain.LeonBrain

/** Small chat window that pops over whatever app you are in (double-tap Leon). Works even when Leon is not floating. */
class ChatActivity : Activity() {

    private lateinit var brain: LeonBrain
    private lateinit var sprites: Sprites
    private lateinit var prefs: Prefs
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var avatar: ImageView
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        brain = (application as LeonApp).brain
        prefs = Prefs(this)
        sprites = Sprites(this)

        window.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        window.setGravity(Gravity.BOTTOM)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(10), dp(12), dp(10))

        // header: Leon's face + title + close
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        avatar = ImageView(this)
        avatar.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        avatar.scaleType = ImageView.ScaleType.FIT_CENTER
        head.addView(avatar)
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8), 0, 0, 0)
        val t1 = TextView(this)
        t1.text = "Leon"
        t1.textSize = 18f
        t1.setTextColor(0xFF2A3550.toInt())
        val t2 = TextView(this)
        t2.text = "offline \u00B7 no internet \u00B7 chats stay on this phone"
        t2.textSize = 11f
        t2.setTextColor(0xFF667085.toInt())
        titles.addView(t1)
        titles.addView(t2)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(this)
        close.text = "\u2715"
        close.setOnClickListener { finish() }
        head.addView(close)
        root.addView(head)

        // messages
        scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)))

        // quick chips
        val chipsScroll = HorizontalScrollView(this)
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for (c in listOf("joke", "quote", "fun fact", "explain gravity", "12*7", "hatian 1250 sa 4", "mute")) {
            val b = Button(this)
            b.text = c
            b.isAllCaps = false
            b.setOnClickListener { send(c) }
            chips.addView(b)
        }
        chipsScroll.addView(chips)
        root.addView(chipsScroll)

        // input row
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        input = EditText(this)
        input.hint = "Say something to Leon..."
        input.maxLines = 3
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { send(input.text.toString()); true } else false
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendBtn = Button(this)
        sendBtn.text = "Send"
        sendBtn.isAllCaps = false
        sendBtn.setOnClickListener { send(input.text.toString()) }
        row.addView(sendBtn)
        root.addView(row)

        setContentView(root)

        setAvatar("happy")
        addMsg(brain.greeting(), false)
        addSystem("Try: joke \u00B7 quote \u00B7 explain gravity \u00B7 12*7 \u00B7 hatian 1250 sa 4 \u00B7 \"ako si Ana\"")
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun setAvatar(name: String) {
        val bmp = sprites.emote(name) ?: sprites.body(name) ?: sprites.emote("happy")
        if (bmp != null) avatar.setImageBitmap(bmp)
    }

    private fun addMsg(text: String, mine: Boolean) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(0xFF1E2A3A.toInt())
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt()
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(if (mine) 0xFFCDF5E2.toInt() else 0xFFF1F3F8.toInt())
        tv.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.setMargins(0, dp(3), 0, dp(3))
        list.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addSystem(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 11f
        tv.setTextColor(0xFF8A94A6.toInt())
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(4), 0, dp(4))
        list.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        addMsg(text, true)
        input.setText("")

        val reply = brain.reply(text)
        val live = LeonOverlayService.live()
        live?.behavior?.onChatReply(reply, true)   // his floating body reacts (mood, sticker, mute ritual, fail-safe)
        setAvatar(reply.emote ?: reply.mood)

        var delay = 350L
        for (line in reply.lines) {
            handler.postDelayed({ addMsg(line, false) }, delay)
            delay += 450L + line.length * 12L
        }

        // Leon is not floating right now: still honour mute / silence in the saved settings
        if (live == null) {
            when (reply.action) {
                Action.MUTE -> {
                    prefs.muted = true
                    handler.postDelayed({ addMsg(brain.line("mute", "beg"), false) }, delay)
                }
                Action.UNMUTE -> {
                    prefs.muted = false
                    prefs.silenceReal = false
                    handler.postDelayed({ addMsg(brain.line("mute", "unmute_ask"), false) }, delay)
                }
                Action.SILENCE_REAL -> {
                    prefs.muted = true
                    prefs.silenceReal = true
                    handler.postDelayed({ addMsg(brain.line("mute", "silence_sob"), false) }, delay)
                }
                Action.CHATTY_DOWN -> prefs.chattiness = maxOf(0, prefs.chattiness - 25)
                Action.NONE -> {}
            }
        }
    }
}
