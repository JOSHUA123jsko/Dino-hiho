package com.leon.dino

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Full-screen, NOT touchable overlay (window alpha 0.79 so Android 12+ lets touches pass through to the app below).
 * Draws everything around Leon: speech bubbles, typed notes, the text card in his hands, the flying
 * "thrown away" card, paper particles, Zzz / tears / hearts / anger marks, and the 25 emote stickers.
 *
 * PRIVACY: text Leon holds only ever lives in a CharArray in RAM and is overwritten with zeros when
 * dropped / thrown / when the screen turns off. Nothing is logged, saved, copied to the clipboard or sent anywhere.
 */
class FxView(ctx: Context, private val sprites: Sprites) : View(ctx) {

    enum class BubbleStyle { SPEECH, NOTE, SHOUT, WHISPER }

    private val d = resources.displayMetrics.density
    private val fs = d * resources.configuration.fontScale

    /** where Leon's window is on screen (set by LeonBehavior every frame) */
    var leonRect = RectF()
    var effects: Set<String> = emptySet()
    var onYarn: (() -> Unit)? = null
    var topLimit = 0f

    private var clock = 0f

    // ---- paints
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val tmp = RectF()

    // ---- bubble
    private var bText = ""
    private var bStyle = BubbleStyle.SPEECH
    private var bShown = 0f
    private var bLastN = 0
    private var bMsPerChar = 30f
    private var bActive = false
    private var bTyped = true
    private var bTypedAt = 0f
    private var bHold = 2.6f

    fun showBubble(text: String, style: BubbleStyle, msPerChar: Long = 30L) {
        bText = text
        bStyle = style
        bShown = 0f
        bLastN = 0
        bMsPerChar = max(1L, msPerChar).toFloat()
        bActive = text.isNotEmpty()
        bTyped = text.isEmpty()
        bTypedAt = clock
        bHold = max(2.6f, text.length * 0.055f)
        invalidate()
    }

    fun hideBubble() {
        bActive = false
        bText = ""
    }

    fun bubbleActive() = bActive
    fun bubbleTyped() = !bActive || bTyped

    // ---- emote sticker pop
    private var emoteName: String? = null
    private var emoteAt = 0f
    private var emoteLen = 1.8f

    fun popEmote(name: String, ms: Long = 1800L) {
        emoteName = name
        emoteAt = clock
        emoteLen = ms / 1000f
    }

    // ---- held / thrown text (RAM only)
    private class Held(val chars: CharArray, val reveal: Boolean) {
        fun wipe() = chars.fill('\u0000')
    }

    private class Fly(
        val held: Held, var x: Float, var y: Float, var vx: Float, var vy: Float,
        var rot: Float, val vr: Float, var life: Float
    )

    private class Bit(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val color: Int)

    private var held: Held? = null
    private var fly: Fly? = null
    private val bits = ArrayList<Bit>()

    fun holdText(text: String, reveal: Boolean) {
        held?.wipe()
        held = Held(text.take(300).toCharArray(), reveal)
    }

    fun hasHeld() = held != null
    fun hasFlying() = fly != null

    /** set it down gently: poof, then the text is destroyed */
    fun dropHeld() {
        val h = held ?: return
        cardRect(tmp)
        poof(tmp.centerX(), tmp.centerY())
        h.wipe()
        held = null
    }

    /** throw it away "like trash": the card flies off, spins, shrinks, bursts into paper bits, then the text is destroyed */
    fun throwHeld(toRight: Boolean) {
        val h = held ?: return
        cardRect(tmp)
        val dir = if (toRight) 1f else -1f
        fly = Fly(
            h, tmp.centerX(), tmp.centerY(),
            dir * (520f + Random.nextInt(280)) * d, -(380f + Random.nextInt(220)) * d,
            0f, dir * (420f + Random.nextInt(360)), 1.5f
        )
        held = null
    }

    /** wipe every trace of held text right now (screen off, user interrupts, service stops) */
    fun wipeAll() {
        held?.wipe(); held = null
        fly?.held?.wipe(); fly = null
        bits.clear()
    }

    fun needsFrames(): Boolean =
        bActive || held != null || fly != null || bits.isNotEmpty() || effects.isNotEmpty() || emoteName != null

    // ---- animation step
    fun step(dtMs: Long) {
        val dt = dtMs / 1000f
        clock += dt

        if (bActive) {
            if (!bTyped) {
                bShown += dtMs / bMsPerChar
                val n = min(bShown.toInt(), bText.length)
                if (n > bLastN) {
                    bLastN = n
                    if (n >= 4 && bText.regionMatches(n - 4, "yarn", 0, 4, ignoreCase = true)) onYarn?.invoke()
                }
                if (bShown >= bText.length) {
                    bShown = bText.length.toFloat()
                    bTyped = true
                    bTypedAt = clock
                }
            } else if (clock - bTypedAt > bHold) {
                hideBubble()
            }
        }

        emoteName?.let { if (clock - emoteAt > emoteLen) emoteName = null }

        fly?.let { f ->
            f.vy += 1500f * d * dt
            f.x += f.vx * dt
            f.y += f.vy * dt
            f.rot += f.vr * dt
            f.life -= dt
            if (f.life <= 0f || f.y > height + 80f * d || f.x < -80f * d || f.x > width + 80f * d) {
                poof(f.x.coerceIn(0f, width.toFloat()), f.y.coerceIn(0f, height.toFloat()))
                f.held.wipe()
                fly = null
            }
        }

        val iter = bits.iterator()
        while (iter.hasNext()) {
            val b = iter.next()
            b.vy += 900f * d * dt
            b.x += b.vx * dt
            b.y += b.vy * dt
            b.life -= dt
            if (b.life <= 0f) iter.remove()
        }
    }

    private fun poof(x: Float, y: Float) {
        val colors = intArrayOf(0xFFFFFDF2.toInt(), 0xFFEFE9D0.toInt(), 0xFFD9D9D9.toInt())
        repeat(16) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val sp = (60f + Random.nextInt(220)) * d
            bits.add(Bit(x, y, cos(a) * sp, sin(a) * sp - 80f * d, 0.5f + Random.nextFloat() * 0.4f, colors[it % 3]))
        }
    }

    // ---- drawing
    override fun onDraw(c: Canvas) {
        drawEffects(c)
        drawHeld(c)
        drawEmote(c)
        drawBubble(c)
        drawFly(c)
        drawBits(c)
    }

    private fun cardRect(r: RectF): RectF {
        val w = 118f * d
        val h = 58f * d
        val lr = leonRect
        var left = lr.left - w * 0.55f
        if (left < 4f * d) left = lr.right - w * 0.45f
        val top = lr.top + lr.height() * 0.50f + sin(clock * 3f) * 2f * d
        r.set(left, top, left + w, top + h)
        return r
    }

    private fun drawCard(c: Canvas, h: Held, r: RectF, alpha: Int) {
        fill.color = 0xFFFFFDF2.toInt(); fill.alpha = alpha
        c.drawRoundRect(r, 5f * d, 5f * d, fill)
        line.color = 0xFF7A7A7A.toInt(); line.alpha = alpha; line.strokeWidth = 1.5f * d
        c.drawRoundRect(r, 5f * d, 5f * d, line)
        // folded corner
        path.reset()
        path.moveTo(r.right - 12f * d, r.top)
        path.lineTo(r.right, r.top + 12f * d)
        path.lineTo(r.right - 12f * d, r.top + 12f * d)
        path.close()
        fill.color = 0xFFE2DCC0.toInt(); fill.alpha = alpha
        c.drawPath(path, fill)

        val pad = 6f * d
        val iw = (r.width() - 2f * pad).toInt()
        if (h.reveal) {
            txt.textSize = 11f * fs
            txt.typeface = Typeface.SANS_SERIF
            txt.color = 0xFF333333.toInt(); txt.alpha = alpha
            val s = String(h.chars)
            val layout = StaticLayout.Builder.obtain(s, 0, s.length, txt, iw)
                .setMaxLines(3).setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build()
            c.save(); c.translate(r.left + pad, r.top + pad); layout.draw(c); c.restore()
        } else {
            fill.color = 0xFFB9B9B9.toInt(); fill.alpha = alpha
            for (i in 0 until 3) {
                tmp.set(r.left + pad, r.top + pad + i * 14f * d, r.right - pad - (i * 14f * d), r.top + pad + i * 14f * d + 8f * d)
                c.drawRoundRect(tmp, 4f * d, 4f * d, fill)
            }
        }
        line.strokeWidth = 2f * d
    }

    private fun drawHeld(c: Canvas) {
        val h = held ?: return
        val r = RectF()
        cardRect(r)
        drawCard(c, h, r, 255)
    }

    private fun drawFly(c: Canvas) {
        val f = fly ?: return
        val w = 118f * d
        val h = 58f * d
        val a = (255f * min(1f, f.life / 0.5f)).toInt().coerceIn(0, 255)
        val s = 0.55f + 0.45f * min(1f, f.life / 1.5f)
        c.save()
        c.translate(f.x, f.y)
        c.rotate(f.rot)
        c.scale(s, s)
        val r = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)
        drawCard(c, f.held, r, a)
        c.restore()
    }

    private fun drawBits(c: Canvas) {
        for (b in bits) {
            fill.color = b.color
            fill.alpha = (255f * min(1f, b.life / 0.35f)).toInt().coerceIn(0, 255)
            c.drawRect(b.x - 3f * d, b.y - 3f * d, b.x + 3f * d, b.y + 3f * d, fill)
        }
    }

    private fun drawEmote(c: Canvas) {
        val name = emoteName ?: return
        val bmp = sprites.emote(name) ?: return
        val t = clock - emoteAt
        val grow = if (t < 0.25f) {
            val k = t / 0.25f
            1.15f * (1f - (1f - k) * (1f - k)) // quick pop with slight overshoot
        } else 1f
        val fade = if (emoteLen - t < 0.3f) max(0f, (emoteLen - t) / 0.3f) else 1f
        val dia = 62f * d * grow
        val lr = leonRect
        val onLeft = lr.centerX() > width / 2f
        val cx = if (onLeft) lr.left - dia * 0.55f else lr.right + dia * 0.35f
        val cy = lr.top + lr.height() * 0.22f
        val a = (255f * fade).toInt()
        fill.color = Color.WHITE; fill.alpha = a
        c.drawCircle(cx, cy, dia / 2f, fill)
        c.save()
        path.reset(); path.addCircle(cx, cy, dia / 2f - 1.5f * d, Path.Direction.CW)
        c.clipPath(path)
        val bh = dia * 1.15f
        val bw = bmp.width * (bh / bmp.height)
        bmpPaint.alpha = a
        tmp.set(cx - bw / 2f, cy - dia / 2f + dia * 0.03f, cx + bw / 2f, cy - dia / 2f + dia * 0.03f + bh)
        c.drawBitmap(bmp, null, tmp, bmpPaint)
        c.restore()
        line.color = 0xFF2A3550.toInt(); line.alpha = a
        c.drawCircle(cx, cy, dia / 2f, line)
    }

    // ---- bubble
    private class BStyle(val fill: Int, val stroke: Int, val text: Int, val size: Float, val face: Typeface)

    private val styles: Map<BubbleStyle, BStyle> = mapOf(
        BubbleStyle.SPEECH to BStyle(0xFFFFFFFF.toInt(), 0xFF2A3550.toInt(), 0xFF2A3550.toInt(), 14f, Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)),
        BubbleStyle.NOTE to BStyle(0xFFFFF6C4.toInt(), 0xFF8A7A2A.toInt(), 0xFF4A4220.toInt(), 13f, Typeface.MONOSPACE),
        BubbleStyle.SHOUT to BStyle(0xFFFFE3E3.toInt(), 0xFFE04848.toInt(), 0xFFC02020.toInt(), 22f, Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)),
        BubbleStyle.WHISPER to BStyle(0xFFEAF8F2.toInt(), 0xFF4A9A7C.toInt(), 0xFF2E6B55.toInt(), 12f, Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC))
    )

    private fun layout(t: CharSequence, w: Int, p: TextPaint): StaticLayout =
        StaticLayout.Builder.obtain(t, 0, t.length, p, max(1, w))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).build()

    private fun drawBubble(c: Canvas) {
        if (!bActive || bText.isEmpty()) return
        val st = bStyle
        val bs = styles.getValue(st)
        val fillC = bs.fill
        val strokeC = bs.stroke
        val textC = bs.text
        val size = bs.size
        val face = bs.face
        txt.textSize = size * fs
        txt.typeface = face
        txt.color = textC
        txt.alpha = 255

        val pad = 10f * d
        val maxInner = (min(width * 0.78f, 280f * d) - 2f * pad).toInt()
        val full = layout(bText, maxInner, txt)
        var widest = 0f
        for (i in 0 until full.lineCount) widest = max(widest, full.getLineWidth(i))
        val innerW = ceil(widest).toInt() + 2
        val bw = innerW + 2f * pad
        val bh = full.height + 2f * pad

        val lr = leonRect
        val cx = lr.centerX()
        val left = (cx - bw / 2f).coerceIn(8f * d, max(8f * d, width - bw - 8f * d))
        var bottom = lr.top + lr.height() * 0.10f - 6f * d
        var top = bottom - bh
        var below = false
        if (top < topLimit + 4f * d) {
            below = true
            top = lr.bottom - lr.height() * 0.04f + 6f * d
            bottom = top + bh
        }
        val rect = RectF(left, top, left + bw, bottom)

        fill.color = fillC; fill.alpha = 255
        c.drawRoundRect(rect, 12f * d, 12f * d, fill)
        line.color = strokeC; line.alpha = 255; line.strokeWidth = 2f * d
        line.pathEffect = if (st == BubbleStyle.NOTE) DashPathEffect(floatArrayOf(8f * d, 5f * d), 0f) else null
        c.drawRoundRect(rect, 12f * d, 12f * d, line)
        line.pathEffect = null

        // tail
        val tx = cx.coerceIn(rect.left + 18f * d, rect.right - 18f * d)
        val edgeY = if (below) rect.top else rect.bottom
        val tipY = if (below) rect.top - 10f * d else rect.bottom + 10f * d
        path.reset()
        path.moveTo(tx - 7f * d, edgeY)
        path.lineTo(cx.coerceIn(rect.left + 8f * d, rect.right - 8f * d), tipY)
        path.lineTo(tx + 7f * d, edgeY)
        fill.color = fillC; fill.alpha = 255
        val close = Path(path); close.close()
        c.drawPath(close, fill)
        c.drawPath(path, line)
        // hide the bubble border where the tail joins
        line.color = fillC
        c.drawLine(tx - 6f * d, edgeY, tx + 6f * d, edgeY, line)

        val n = min(bShown.toInt(), bText.length)
        val shown = if (n <= 0) " " else bText.substring(0, n)
        val cur = layout(shown, innerW, txt)
        c.save()
        c.translate(rect.left + pad, rect.top + pad)
        cur.draw(c)
        c.restore()
    }

    // ---- effects around Leon
    private fun drawEffects(c: Canvas) {
        if (effects.isEmpty()) return
        val lr = leonRect
        val w = lr.width()
        val h = lr.height()
        for (e in effects) {
            when (e) {
                "zzz" -> {
                    txt.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
                    for (i in 0 until 3) {
                        val ph = (clock * 0.45f + i / 3f) % 1f
                        txt.textSize = (10f + 9f * ph) * fs
                        txt.color = 0xFF3A5BD9.toInt()
                        txt.alpha = (255f * (1f - ph)).toInt()
                        c.drawText("Z", lr.right - w * 0.30f + ph * 22f * d + i * 3f * d, lr.top + h * 0.28f - ph * 34f * d, txt)
                    }
                    txt.alpha = 255
                }
                "tears" -> {
                    for (side in 0..1) {
                        val ph = (clock * 0.9f + side * 0.5f) % 1f
                        val x = lr.centerX() + (if (side == 0) -0.17f else 0.19f) * w
                        val y = lr.top + h * 0.40f + ph * h * 0.22f
                        fill.color = 0xFF6EC6FF.toInt(); fill.alpha = (255f * (1f - ph * 0.8f)).toInt()
                        c.drawCircle(x, y, 3.2f * d, fill)
                    }
                }
                "hearts" -> {
                    for (i in 0 until 3) {
                        val ph = (clock * 0.55f + i / 3f) % 1f
                        heart(c, lr.centerX() + (i - 1) * w * 0.22f + sin(clock * 2f + i) * 4f * d, lr.top + h * 0.2f - ph * 34f * d, (4f + 3f * ph) * d, 0xFFFF5C8A.toInt(), (255f * (1f - ph)).toInt())
                    }
                }
                "anger" -> {
                    val x = lr.right - w * 0.18f
                    val y = lr.top + h * 0.12f
                    val r = 8f * d * (1f + 0.15f * sin(clock * 14f))
                    line.color = 0xFFE02020.toInt(); line.alpha = 255; line.strokeWidth = 2.5f * d
                    for (i in 0 until 4) {
                        val a = i * (PI / 2).toFloat() + 0.4f
                        c.drawLine(x + cos(a) * r * 0.5f, y + sin(a) * r * 0.5f, x + cos(a) * r, y + sin(a) * r, line)
                    }
                    line.strokeWidth = 2f * d
                }
                "sweat" -> {
                    val x = lr.centerX() + w * 0.26f
                    val y = lr.top + h * 0.20f + (sin(clock * 3f) + 1f) * 2f * d
                    fill.color = 0xFF6EC6FF.toInt(); fill.alpha = 230
                    c.drawCircle(x, y, 3.6f * d, fill)
                }
                "sparkle" -> {
                    for (i in 0 until 4) {
                        val ph = (clock * 0.8f + i * 0.25f) % 1f
                        val x = lr.left + w * (0.1f + 0.27f * i)
                        val y = lr.top + h * (0.15f + 0.2f * ((i * 3) % 4)) - ph * 6f * d
                        star(c, x, y, (3f + 4f * sin(ph * PI.toFloat())) * d)
                    }
                }
            }
        }
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, alpha: Int) {
        path.reset()
        path.moveTo(cx, cy + s * 0.9f)
        path.cubicTo(cx - s * 1.6f, cy - s * 0.2f, cx - s * 0.7f, cy - s * 1.3f, cx, cy - s * 0.4f)
        path.cubicTo(cx + s * 0.7f, cy - s * 1.3f, cx + s * 1.6f, cy - s * 0.2f, cx, cy + s * 0.9f)
        path.close()
        fill.color = color; fill.alpha = alpha.coerceIn(0, 255)
        c.drawPath(path, fill)
    }

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        path.moveTo(cx, cy - r); path.lineTo(cx + r * 0.3f, cy - r * 0.3f)
        path.lineTo(cx + r, cy); path.lineTo(cx + r * 0.3f, cy + r * 0.3f)
        path.lineTo(cx, cy + r); path.lineTo(cx - r * 0.3f, cy + r * 0.3f)
        path.lineTo(cx - r, cy); path.lineTo(cx - r * 0.3f, cy - r * 0.3f)
        path.close()
        fill.color = 0xFFFFD84A.toInt(); fill.alpha = 230
        c.drawPath(path, fill)
    }
}
