package com.leon.dino

import android.app.Application
import com.leon.dino.brain.LeonBrain

class LeonApp : Application() {
    /** One brain for the whole app (service + chat window share it, so he never repeats himself). */
    val brain: LeonBrain by lazy { LeonBrain(this) }
}
