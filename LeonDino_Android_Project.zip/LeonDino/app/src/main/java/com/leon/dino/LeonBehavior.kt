package com.leon.dino

import android.graphics.Rect
import android.os.SystemClock
import com.leon.dino.brain.Action
import com.leon.dino.brain.LeonBrain
import com.leon.dino.brain.Reply
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Leon's "life": walking, sleeping, boredom, touching text, the mute-button breakdown.
 * Everything runs on the main thread. Time-ordered behaviours are written as small scripts
 * (say / walk / pause / act / until) so the sequences read like the character bible.
 */
class LeonBehavior(private val svc: LeonOverlayService) : ScreenReaderService.Listener {

    private val prefs: Prefs get() = svc.prefs
    private val brain: LeonBrain get() = svc.brain
    private val fx: FxView get() = svc.fx
    private val d: Float get() = svc.density
    private val scheduler by lazy { SleepScheduler(svc.prefs) }

    enum class Sleep { NONE, NAP, NIGHT }

    // ------------------------------------------------------------------ state
    var x = 0f
    var y = 0f
    var winSize = 0

    private var tx = 0f
    private var ty = 0f
    private var moving = false
    private var speedPx = 0f
    private var faceRight = false

    var sleep = Sleep.NONE
        private set
    private var sleepUntil = 0L

    private var script: Script? = null
    private var sub: Script? = null
    private var token = 0
    private var scanPending = false
    private var readPending = false
    private var heldKind = "generic"
    private var blockers: List<Rect> = emptyList()
    private var lastBlockerScan = 0L

    private var boredomActive = false
    private var idleMs = 0L
    private var wanderWait = 3500L
    private var chatterWait = 90_000L
    private var textCooldown = 60_000L
    private var mutedNoteWait = 60_000L
    private var schedClock = 1000L
    private var awakeAcc = 0L
    private var muteStartedAt = 0L

    private var mood = "happy"
    private var effects: Set<String> = emptySet()
    private var clock = 0f
    private var yarnWiggle = 0f
    private var screamLeft = 0f

    var dragging = false
        private set
    private var kb: Rect? = null

    // ------------------------------------------------------------------ lifecycle

    fun start(px: Float, py: Float) {
        x = px; y = py; tx = px; ty = py
        fx.onYarn = { yarnWiggle = 0.6f }
        ScreenReaderService.listener = this
        schedClock = 1000L
        refreshKeyboard()
        if (!prefs.muted) {
            play("hello") {
                pause(900L)
                say({ brain.greeting() }, look = "happy", emote = "cheerful")
            }
        } else {
            mood = "sad"
        }
    }

    fun stop() {
        flushAwake()
        ScreenReaderService.listener = null
        cancelScripts()
        fx.wipeAll()
        prefs.posX = x.toInt()
        prefs.posY = y.toInt()
    }

    private fun flushAwake() {
        if (awakeAcc > 0L) {
            prefs.awakeMs = prefs.awakeMs + awakeAcc
            awakeAcc = 0L
        }
    }

    // ------------------------------------------------------------------ per-frame

    fun update(dtMs: Long) {
        val dt = dtMs / 1000f
        clock += dt
        if (yarnWiggle > 0f) yarnWiggle = max(0f, yarnWiggle - dt)
        if (screamLeft > 0f) screamLeft = max(0f, screamLeft - dt)

        schedClock += dtMs
        if (schedClock >= 1000L) {
            schedClock = 0L
            schedule()
        }
        if (sleep != Sleep.NONE) return

        awakeAcc += dtMs
        if (awakeAcc >= 30_000L) flushAwake()
        if (dragging) return

        idleMs += dtMs
        stepScripts(dtMs)
        if (script == null && sub == null) autonomous(dtMs)
        move(dtMs)
    }

    fun frameDelayMs(): Long = when {
        sleep == Sleep.NIGHT -> 500L
        sleep == Sleep.NAP -> 100L
        moving || dragging || screamLeft > 0f || yarnWiggle > 0f || fx.hasFlying() ||
            (fx.bubbleActive() && !fx.bubbleTyped()) -> 33L
        else -> 100L // 10 FPS when idle
    }

    fun applyVisual() {
        val t = clock
        var sx = 1f
        var sy = 1f
        var rot = 0f
        var dy = 0f
        var sprite = mood
        val speaking = fx.bubbleActive() && !fx.bubbleTyped()
        when {
            sleep != Sleep.NONE -> { val b = sin(t * 1.4f) * 0.02f; sy += b; sx -= b * 0.7f; sprite = "sleepy" }
            dragging -> { rot = sin(t * 9f) * 8f; sy = 1.04f; sprite = "excited" }
            moving -> {
                val ph = abs(sin(t * 11f))
                dy = -ph * 7f * d; rot = sin(t * 11f) * 5f; sy += 0.05f * ph; sx -= 0.03f * ph
            }
            else -> { val b = sin(t * 2.2f) * 0.02f; sy += b; sx -= b * 0.7f } // breathing
        }
        if (speaking && sleep == Sleep.NONE && !dragging) {
            val ph = sin(t * 17f)
            sy += 0.04f * ph; sx -= 0.03f * ph
            if (sprite == "happy" || sprite == "excited") sprite = if (sin(t * 8.5f) > 0f) "happy" else "excited"
        }
        if (yarnWiggle > 0f) rot += sin(t * 40f) * 9f * min(1f, yarnWiggle * 2f)
        if (screamLeft > 0f) {
            sx *= 1.18f; sy *= 1.18f
            dy += sin(t * 60f) * 3f * d; rot += sin(t * 55f) * 4f
            sprite = "excited"
        }
        svc.leonView.set(sprite, faceRight, sx, sy, rot, dy)
        fx.leonRect.set(x, y, x + winSize, y + winSize)
        fx.effects = effects
        fx.topLimit = svc.safeTop.toFloat()
    }

    // ------------------------------------------------------------------ schedule: nap + night

    private fun schedule() {
        val now = System.currentTimeMillis()
        val night = scheduler.nightNow()
        when (sleep) {
            Sleep.NONE -> {
                if (night) enterSleep(Sleep.NIGHT)
                else if (scheduler.napDue(prefs.awakeMs + awakeAcc)) enterSleep(Sleep.NAP)
            }
            Sleep.NAP -> {
                if (night) enterSleep(Sleep.NIGHT) else if (now >= sleepUntil) wake()
            }
            Sleep.NIGHT -> if (!night) wake()
        }
    }

    private fun enterSleep(kind: Sleep) {
        val from = sleep
        cancelScripts(); fx.wipeAll(); fx.hideBubble(); svc.voice.stop()
        flushAwake()
        moving = false; dragging = false; boredomActive = false; screamLeft = 0f
        sleep = kind
        mood = "sleepy"; effects = setOf("zzz")
        if (kind == Sleep.NAP) {
            sleepUntil = System.currentTimeMillis() + prefs.napMinutes * 60_000L
            if (from == Sleep.NONE && !prefs.silenceReal) speak(brain.line("sleep", "nap_start"), FxView.BubbleStyle.WHISPER)
        } else {
            // deep sleep: stop moving, no sounds, shrink + fade, tuck into the corner
            svc.setNightLook(true)
            val s = svc.safe()
            x = max(s.left, s.right - winSize).toFloat()
            y = max(s.top, s.bottom - winSize).toFloat()
        }
    }

    private fun wake() {
        val was = sleep
        sleep = Sleep.NONE
        if (was == Sleep.NIGHT) { svc.setNightLook(false); clampInside() }
        prefs.awakeMs = 0L; awakeAcc = 0L
        effects = emptySet(); mood = if (prefs.muted) "sad" else "happy"
        idleMs = 0L; wanderWait = 4000L
        if (!prefs.silenceReal) speak(brain.line("sleep", if (was == Sleep.NAP) "nap_wake" else "night_wake"))
    }

    // ------------------------------------------------------------------ autonomy

    private fun autonomous(dt: Long) {
        if (scanPending || readPending) return
        if (overlapsKeyboard()) { escapeKeyboard(); return }
        if (prefs.muted) { mutedIdle(dt); return }

        if (idleMs >= prefs.boredMinutes * 60_000L && !boredomActive) { startBoredom(); return }

        wanderWait -= dt; chatterWait -= dt; textCooldown -= dt
        if (chatterWait <= 0L) {
            chatterWait = nextChatterDelay()
            if (prefs.chattiness > 0 && !fx.bubbleActive() && kb == null) {
                mood = "happy"
                speak(brain.chatter())
                return
            }
        }
        if (wanderWait <= 0L) {
            wanderWait = 5_000L + Random.nextLong(9_000L)
            val roll = Random.nextInt(100)
            if (textCooldown <= 0L && prefs.readText && ScreenReaderService.isEnabled() && kb == null && roll < prefs.curiosity) {
                textCooldown = 120_000L
                startTextTouch(bored = false)
            } else if (roll < 85) {
                startWander()
            }
        }
    }

    private fun nextChatterDelay(): Long {
        val c = prefs.chattiness.coerceIn(0, 100)
        if (c == 0) return 3_600_000L
        val minutes = 20.0 - 16.0 * c / 100.0
        return (minutes * 60_000.0 * (0.7 + Random.nextDouble() * 0.6)).toLong()
    }

    private fun mutedIdle(dt: Long) {
        if (prefs.silenceReal) return
        mutedNoteWait -= dt
        if (mutedNoteWait <= 0L) {
            mutedNoteWait = 120_000L + Random.nextLong(180_000L)
            if (!fx.bubbleActive()) { mood = "sad"; speak(brain.line("mute", "idle"), FxView.BubbleStyle.NOTE) }
        }
    }

    private fun startWander() {
        val p = randomPoint()
        val spd = 70f + Random.nextInt(60)
        play("wander") {
            walk(p.first, p.second, spd)
            act { if (Random.nextInt(4) == 0) mood = if (mood == "happy") "excited" else "happy" }
        }
        refreshBlockers()
    }

    /** a spot inside the safe area that avoids buttons / text fields seen in the last scan */
    private fun randomPoint(): Pair<Float, Float> {
        val s = svc.safe()
        val maxX = max(s.left, s.right - winSize).toFloat()
        val maxY = max(s.top, s.bottom - winSize).toFloat()
        var bx = x; var by = y; var best = Float.MAX_VALUE
        repeat(8) {
            val cx = s.left + Random.nextFloat() * (maxX - s.left)
            val cy = s.top + Random.nextFloat() * (maxY - s.top)
            val r = Rect(cx.toInt(), cy.toInt(), cx.toInt() + winSize, cy.toInt() + winSize)
            var overlap = 0L
            for (b in blockers) {
                if (Rect.intersects(b, r)) {
                    val i = Rect(b)
                    if (i.intersect(r)) overlap += i.width().toLong() * i.height()
                }
            }
            val tiny = if (hypot(cx - x, cy - y) < 80f * d) 1e9f else 0f
            val score = overlap.toFloat() + tiny
            if (score < best) { best = score; bx = cx; by = cy }
        }
        return Pair(bx, by)
    }

    /** bounds only (no text) so he can walk around buttons. Rate-limited to save battery. */
    private fun refreshBlockers() {
        val reader = ScreenReaderService.instance ?: return
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlockerScan < 5_000L) return
        lastBlockerScan = now
        reader.scanAsync { res -> blockers = res.blockers }
    }

    // ------------------------------------------------------------------ keyboard

    override fun onWindowsChanged() { refreshKeyboard() }

    fun refreshKeyboard() {
        kb = ScreenReaderService.instance?.keyboardBounds()
        svc.setGhost(kb != null && overlapsKeyboard())
    }

    fun keyboardTop(): Int? = kb?.top

    private fun overlapsKeyboard(): Boolean {
        val k = kb ?: return false
        return Rect.intersects(k, Rect(x.toInt(), y.toInt(), x.toInt() + winSize, y.toInt() + winSize))
    }

    private fun escapeKeyboard() {
        val k = kb ?: return
        val s = svc.safe()
        goTo(x, max(s.top.toFloat(), k.top - winSize - 4f * d), 170f)
    }

    // ------------------------------------------------------------------ movement

    private fun goTo(px: Float, py: Float, speedDp: Float = 90f) {
        val s = svc.safe()
        val maxX = max(s.left, s.right - winSize).toFloat()
        val maxY = max(s.top, s.bottom - winSize).toFloat()
        tx = px.coerceIn(s.left.toFloat(), maxX)
        ty = py.coerceIn(s.top.toFloat(), maxY)
        speedPx = speedDp * d
        moving = true
    }

    private fun move(dt: Long) {
        if (!moving) return
        val dx = tx - x
        val dy = ty - y
        val dist = hypot(dx, dy)
        val step = speedPx * dt / 1000f
        if (dist <= step || dist < 1f) {
            x = tx; y = ty; moving = false
            return
        }
        x += dx / dist * step
        y += dy / dist * step
        if (abs(dx) > 2f) faceRight = dx > 0f
    }

    private fun clampInside() {
        val s = svc.safe()
        x = x.coerceIn(s.left.toFloat(), max(s.left, s.right - winSize).toFloat())
        y = y.coerceIn(s.top.toFloat(), max(s.top, s.bottom - winSize).toFloat())
        tx = x; ty = y
    }

    fun onScreenChanged() { if (sleep == Sleep.NONE || sleep == Sleep.NAP) clampInside() }

    // ------------------------------------------------------------------ speaking

    fun speak(text: String, style: FxView.BubbleStyle = FxView.BubbleStyle.SPEECH) {
        if (text.isBlank() || sleep == Sleep.NIGHT) return
        val st = if (prefs.muted) FxView.BubbleStyle.NOTE else style
        fx.showBubble(text, st, if (st == FxView.BubbleStyle.SHOUT) 20L else 30L)
        if (!prefs.muted && sleep == Sleep.NONE && st != FxView.BubbleStyle.NOTE) svc.voice.speak(text)
    }

    // ------------------------------------------------------------------ boredom (stages 1-5 from the bible)

    private fun startBoredom() {
        boredomActive = true
        play("bored", onEnd = {
            boredomActive = false; idleMs = 0L; screamLeft = 0f
            effects = emptySet(); mood = "happy"; wanderWait = 6_000L
        }) {
            // 1 commentary
            act { mood = "pouty"; effects = setOf("sweat") }
            say({ brain.line("boredom", "s1") }, look = "pouty", emote = "pouty", hold = 1200L)
            pause(2500L)
            // 2 random fact
            act { mood = "thinking"; effects = emptySet() }
            say({ brain.fact() }, look = "thinking", emote = "surprised", hold = 1500L)
            pause(2000L)
            // 3 quote spam
            act { mood = "excited" }
            say({ brain.line("boredom", "s3_intro") }, look = "excited", hold = 300L)
            say({ brain.quote() }, look = "excited", hold = 1200L)
            say({ brain.quote() }, look = "thinking", hold = 1200L)
            // 4 restless: pacing, then goes and grabs some text from the screen
            act { mood = "angry" }
            say({ brain.line("boredom", "s4") }, look = "angry", hold = 500L)
            act { val p = randomPoint(); goTo(p.first, p.second, 190f) }
            until { !moving }
            act { val p = randomPoint(); goTo(p.first, p.second, 190f) }
            until { !moving }
            say({ brain.line("boredom", "s4_text") }, look = "angry", hold = 400L)
            act { startTextTouch(bored = true) }
            // 5 (scream + throw happen inside the touch sub-script)
            until { !scanPending && !readPending && sub == null }
            act { mood = "shy"; effects = emptySet() }
            say({ brain.line("boredom", "s5_after") }, look = "shy", emote = "embarrassed", hold = 800L)
        }
    }

    private fun endBoredomEarly() {
        cancelScripts()
        boredomActive = false; screamLeft = 0f
        effects = emptySet(); mood = "happy"
        fx.wipeAll()
        if (!prefs.muted && sleep == Sleep.NONE) speak(brain.line("boredom", "relief"))
    }

    // ------------------------------------------------------------------ touching text (read-only)

    private fun startTextTouch(bored: Boolean) {
        val reader = ScreenReaderService.instance
        if (reader == null || !prefs.readText) { playTouch(bored, null); return }
        val my = token
        scanPending = true
        reader.scanAsync { res ->
            if (my != token) return@scanAsync
            scanPending = false
            val box = if (res.textBoxes.isEmpty()) null else res.textBoxes[Random.nextInt(res.textBoxes.size)]
            playTouch(bored, box)
        }
    }

    private fun playTouch(bored: Boolean, box: Rect?) {
        if (!bored && box == null) { startWander(); return } // nothing to touch on this screen
        val build: SB.() -> Unit = {
            if (box != null) {
                val px = box.exactCenterX() - winSize / 2f
                val py = box.exactCenterY() - winSize * 0.60f
                act { mood = "excited"; effects = emptySet() }
                walk(px, py, if (bored) 170f else 100f)
            }
            act { mood = "thinking"; grabText(box) }
            until { !readPending }
            say({ brain.line("text", heldKind) }, look = "thinking", hold = 700L)
            pause(1500L)
            if (bored) {
                act { mood = "excited"; screamLeft = 2.0f; effects = setOf("anger") }
                say({ brain.line("boredom", "s5_scream") }, FxView.BubbleStyle.SHOUT, look = "excited", emote = "scream", hold = 500L)
                say({ brain.line("boredom", "s5_throw") }, look = "angry", hold = 250L)
                act { fx.throwHeld(Random.nextBoolean()) }
                until { !fx.hasFlying() }
                act { screamLeft = 0f; effects = emptySet() }
            } else {
                act { fx.dropHeld() }
                pause(500L)
                act { mood = "happy" }
            }
        }
        if (bored) playSub("touch", build) else play("touch", {}, build)
    }

    /** the one and only moment text is read: Leon's hand touches the element, the string goes straight into RAM */
    private fun grabText(box: Rect?) {
        val reader = ScreenReaderService.instance
        if (box == null || reader == null) { holdScrap(); return }
        readPending = true
        val my = token
        reader.readTextAsync(box.centerX(), box.centerY()) { t ->
            if (my != token) return@readTextAsync
            readPending = false
            if (t.isNullOrBlank()) {
                holdScrap()
            } else {
                heldKind = brain.kindOf(t)
                fx.holdText(t, prefs.showHeldText)
            }
        }
    }

    private fun holdScrap() {
        heldKind = "generic"
        fx.holdText("x\u00B2 + y\u00B2 = r\u00B2   (scrap paper)", true)
    }

    // ------------------------------------------------------------------ the mute button

    fun setMuted(m: Boolean) {
        if (m == prefs.muted) return
        prefs.muted = m
        if (!m) prefs.silenceReal = false
        svc.updateNotification()
        if (sleep != Sleep.NONE) return
        userActive()
        if (m) startMuteRitual() else startUnmute()
    }

    private fun startMuteRitual() {
        muteStartedAt = SystemClock.elapsedRealtime()
        svc.voice.stop()
        val now = System.currentTimeMillis()
        val recent = now - prefs.lastMuteRitual < 10 * 60_000L // once per scene: short version if it just happened
        prefs.lastMuteRitual = now
        val note = FxView.BubbleStyle.NOTE
        play("mute") {
            if (recent) {
                act { effects = setOf("tears") }
                say({ brain.line("mute", "short") }, note, look = "sad", emote = "sad", hold = 1200L)
            } else {
                act { mood = "surprised"; effects = emptySet() }
                say({ brain.line("mute", "confused") }, note, look = "surprised", emote = "confused", hold = 900L)
                say({ brain.line("mute", "bargain") }, note, look = "shy", emote = "begging", hold = 900L)
                say({ brain.line("mute", "beg") }, note, look = "sad", emote = "begging", fxs = setOf("tears"), hold = 900L)
                say({ brain.line("mute", "sniffle") }, note, look = "sad", fxs = setOf("tears"), hold = 1000L)
            }
            act { parkSad() }
        }
    }

    private fun startUnmute() {
        val prank = SystemClock.elapsedRealtime() - muteStartedAt < 10_000L
        play("unmute", onEnd = { mood = "happy"; idleMs = 0L }) {
            act { mood = "shy"; effects = emptySet() }
            // he asks permission first, small voice, then recovers: quote + joke + tiny sorry
            say({ brain.line("mute", "unmute_ask") }, FxView.BubbleStyle.WHISPER, look = "shy", emote = "begging", hold = 3500L)
            if (prank) say({ brain.line("mute", "prank") }, FxView.BubbleStyle.SHOUT, look = "angry", emote = "laughing", hold = 800L)
            say({ brain.muteQuote() }, FxView.BubbleStyle.WHISPER, look = "happy", hold = 1200L)
            say({ brain.joke() }, look = "excited", emote = "laughing", hold = 1500L)
            say({ brain.line("mute", "unmute_sorry") }, FxView.BubbleStyle.WHISPER, look = "shy", hold = 800L)
        }
    }

    /** "Leon, I need silence for real, not joke": one last dramatic sob, then he respects it completely. */
    fun silenceReal() {
        prefs.muted = true
        svc.updateNotification()
        svc.voice.stop()
        if (sleep != Sleep.NONE) { prefs.silenceReal = true; return }
        val note = FxView.BubbleStyle.NOTE
        play("silence", onEnd = { prefs.silenceReal = true }) {
            act { mood = "sad"; effects = setOf("tears") }
            say({ brain.line("mute", "silence_sob") }, note, look = "sad", emote = "sad", hold = 900L)
            pause(700L)
            act { effects = emptySet() }
            say({ brain.line("mute", "silence_ack") }, note, look = "sad", hold = 800L)
            act { parkSad() }
        }
    }

    /** stays close, like a sad puppy that was told "stay" */
    private fun parkSad() {
        val s = svc.safe()
        goTo(max(s.left, s.right - winSize).toFloat(), max(s.top, s.bottom - winSize).toFloat(), 70f)
        mood = "sad"
        effects = emptySet()
    }

    // ------------------------------------------------------------------ touch + chat

    private fun userActive() {
        idleMs = 0L
        if (boredomActive) endBoredomEarly()
    }

    fun onTap() {
        val wasBored = boredomActive
        userActive()
        if (wasBored) return
        when (sleep) {
            Sleep.NAP -> { speak(brain.line("sleep", "tapped_nap"), FxView.BubbleStyle.WHISPER); return }
            Sleep.NIGHT -> return
            Sleep.NONE -> {}
        }
        if (prefs.muted) {
            if (!prefs.silenceReal) { mood = "sad"; fx.popEmote("sad"); speak(brain.line("mute", "short"), FxView.BubbleStyle.NOTE) }
            return
        }
        mood = listOf("happy", "excited", "shy", "love").random()
        speak(brain.poke())
    }

    fun onDoubleTap() {
        userActive()
        if (sleep == Sleep.NONE) svc.openChat()
    }

    fun onLongPress() { setMuted(!prefs.muted) }

    fun onDragStart() {
        userActive()
        cancelScripts()
        dragging = true; moving = false
        if (sleep == Sleep.NONE) {
            mood = "excited"
            fx.hideBubble()
            if (!prefs.muted) speak(brain.dragLine())
        }
    }

    fun onDragMove(nx: Float, ny: Float) {
        val b = svc.screenBounds()
        x = nx.coerceIn(b.left.toFloat(), max(b.left, b.right - winSize).toFloat())
        y = ny.coerceIn(b.top.toFloat(), max(b.top, b.bottom - winSize).toFloat())
        tx = x; ty = y
    }

    fun onDragEnd() {
        dragging = false
        idleMs = 0L
        wanderWait = 5_000L
        if (sleep == Sleep.NONE) {
            mood = if (prefs.muted) "sad" else "happy"
            if (!prefs.muted) speak(brain.dropLine())
        }
        refreshKeyboard()
    }

    /** Leon's brain answered something typed in the chat window; his body reacts (and speaks if the chat window is closed). */
    fun onChatReply(r: Reply, chatOpen: Boolean) {
        userActive()
        when (r.action) {
            Action.MUTE -> { setMuted(true); return }
            Action.UNMUTE -> { setMuted(false); return }
            Action.SILENCE_REAL -> { silenceReal(); return }
            Action.CHATTY_DOWN -> prefs.chattiness = max(0, prefs.chattiness - 25)
            Action.NONE -> {}
        }
        if (sleep != Sleep.NONE) return
        mood = r.mood
        r.emote?.let { fx.popEmote(it) }
        if (!chatOpen && r.lines.isNotEmpty() && !prefs.muted) {
            val lines = r.lines
            play("reply") {
                for (ln in lines) say(ln, look = r.mood, hold = 600L)
            }
        }
    }

    // ------------------------------------------------------------------ screen on / off

    fun onScreenOff() {
        if (script != null || sub != null) {
            cancelScripts()
            boredomActive = false
            if (sleep == Sleep.NONE) { mood = if (prefs.muted) "sad" else "happy"; effects = emptySet() }
        }
        screamLeft = 0f
        fx.wipeAll()          // privacy: nothing held survives a screen-off
        fx.hideBubble()
        flushAwake()
    }

    fun onScreenOn() {
        schedClock = 1000L
        refreshKeyboard()
        if (prefs.muted && sleep == Sleep.NONE) parkSad()
    }

    // ------------------------------------------------------------------ tiny script engine

    private interface Step {
        fun start() {}
        fun update(dt: Long): Boolean
    }

    private class Script(val name: String, val steps: List<Step>, val onEnd: () -> Unit) {
        var index = 0
        var started = false
        var cancelled = false
    }

    private inner class SB {
        val steps = ArrayList<Step>()

        fun pause(ms: Long) {
            steps.add(object : Step {
                var t = 0L
                override fun update(dt: Long): Boolean { t += dt; return t >= ms }
            })
        }

        fun act(block: () -> Unit) {
            steps.add(object : Step {
                override fun start() { block() }
                override fun update(dt: Long) = true
            })
        }

        fun until(cond: () -> Boolean) {
            steps.add(object : Step {
                override fun update(dt: Long) = cond()
            })
        }

        fun walk(px: Float, py: Float, speedDp: Float = 90f) {
            steps.add(object : Step {
                override fun start() { goTo(px, py, speedDp) }
                override fun update(dt: Long) = !moving
            })
        }

        fun say(
            provider: () -> String,
            style: FxView.BubbleStyle = FxView.BubbleStyle.SPEECH,
            look: String? = null,
            hold: Long = 900L,
            emote: String? = null,
            fxs: Set<String>? = null
        ): Unit {
            steps.add(object : Step {
                var after = 0L
                override fun start() {
                    if (look != null) mood = look
                    if (fxs != null) effects = fxs
                    if (emote != null) fx.popEmote(emote)
                    speak(provider(), style)
                }
                override fun update(dt: Long): Boolean {
                    if (fx.bubbleTyped()) after += dt
                    return after >= hold
                }
            })
        }

        fun say(
            text: String,
            style: FxView.BubbleStyle = FxView.BubbleStyle.SPEECH,
            look: String? = null,
            hold: Long = 900L,
            emote: String? = null,
            fxs: Set<String>? = null
        ): Unit {
            say({ text }, style, look, hold, emote, fxs)
        }
    }

    private fun play(name: String, onEnd: () -> Unit = {}, build: SB.() -> Unit) {
        cancelScripts()
        script = Script(name, SB().apply(build).steps, onEnd)
    }

    private fun playSub(name: String, build: SB.() -> Unit) {
        sub = Script(name, SB().apply(build).steps) {}
    }

    private fun cancelScripts() {
        script?.cancelled = true
        sub?.cancelled = true
        script = null
        sub = null
        token++
        scanPending = false
        readPending = false
        moving = false
    }

    private fun stepScripts(dt: Long) {
        val s = sub ?: script ?: return
        if (s.index >= s.steps.size) {
            if (s === sub) sub = null else script = null
            s.onEnd()
            return
        }
        val st = s.steps[s.index]
        if (!s.started) {
            s.started = true
            st.start()
            if (s.cancelled) return
        }
        if (st.update(dt)) {
            s.index++
            s.started = false
        }
    }
}
