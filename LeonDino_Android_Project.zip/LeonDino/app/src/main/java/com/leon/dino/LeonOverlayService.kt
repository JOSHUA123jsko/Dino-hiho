package com.leon.dino

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import com.leon.dino.brain.LeonBrain
import kotlin.math.hypot
import kotlin.math.max

/**
 * Hosts Leon on top of every app and the home screen using TWO overlay windows:
 *   - leonView : small, touchable, opaque  (drag / tap / double-tap = chat / long-press = mute)
 *   - fx       : full-screen, NOT touchable, alpha 0.79 (bubbles, held text, effects). Alpha <= 0.8 is required on
 *                Android 12+ or the system silently blocks every touch that would reach the app underneath.
 */
class LeonOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.leon.dino.action.STOP"
        const val ACTION_MUTE_TOGGLE = "com.leon.dino.action.MUTE_TOGGLE"
        private const val CHANNEL = "leon_channel"
        private const val NOTIF_ID = 42

        @Volatile
        var instance: LeonOverlayService? = null

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, LeonOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LeonOverlayService::class.java))
        }

        fun isRunning(): Boolean = instance != null

        /** the running service, but only once Leon is fully set up (safe to call behavior/fx on it) */
        fun live(): LeonOverlayService? = instance?.takeIf { it.ready }
    }

    lateinit var prefs: Prefs
    lateinit var brain: LeonBrain
    lateinit var voice: LeonVoice
    lateinit var sprites: Sprites
    lateinit var leonView: LeonView
    lateinit var fx: FxView
    lateinit var behavior: LeonBehavior

    var density = 1f
        private set
    var safeTop = 0
        private set

    private lateinit var wm: WindowManager
    private lateinit var leonLp: WindowManager.LayoutParams
    private lateinit var fxLp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false
    private var running = false
    private var lastFrame = 0L
    private var lastX = Int.MIN_VALUE
    private var lastY = Int.MIN_VALUE
    private var baseSize = 0
    private var ghostOn = false
    private var nightOn = false
    private var fxWasActive = false
    private var screenRect = Rect()
    private var baseSafe = Rect()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        density = resources.displayMetrics.density
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        brain = (application as LeonApp).brain
        brain.cleanMode = prefs.cleanMode
        sprites = Sprites(this)
        voice = LeonVoice(this, prefs)
        fx = FxView(this, sprites)
        leonView = LeonView(this, sprites)
        behavior = LeonBehavior(this)

        refreshMetrics()
        baseSize = (prefs.sizeDp * density * 1.15f).toInt()
        behavior.winSize = baseSize

        val startX = if (prefs.posX >= 0) prefs.posX else baseSafe.right - baseSize - (8 * density).toInt()
        val startY = if (prefs.posY >= 0) prefs.posY else baseSafe.bottom - (baseSize * 1.6f).toInt()

        fxLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 0.79f
            title = "LeonFx"
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        leonLp = WindowManager.LayoutParams(
            baseSize, baseSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
            title = "LeonBody"
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        try {
            wm.addView(fx, fxLp)
            wm.addView(leonView, leonLp)
        } catch (e: Exception) {
            // overlay permission was revoked or the system refused the window
            stopSelf()
            return
        }
        installTouch()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)

        behavior.start(startX.toFloat(), startY.toFloat())
        ready = true
        val pm = getSystemService(PowerManager::class.java)
        if (pm == null || pm.isInteractive) resumeLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_MUTE_TOGGLE -> if (ready) behavior.setMuted(!prefs.muted)
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (ready) {
            refreshMetrics()
            behavior.onScreenChanged()
        }
    }

    override fun onDestroy() {
        if (ready) {
            running = false
            handler.removeCallbacksAndMessages(null)
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) { }
            behavior.stop()
            fx.wipeAll()
            try { wm.removeView(leonView) } catch (e: Exception) { }
            try { wm.removeView(fx) } catch (e: Exception) { }
            voice.shutdown()
            ready = false
        }
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ geometry (used by LeonBehavior)

    private fun refreshMetrics() {
        screenRect = ScreenMetrics.bounds(this, wm)
        val i = ScreenMetrics.insets(this, wm)
        baseSafe = Rect(screenRect.left + i.left, screenRect.top + i.top, screenRect.right - i.right, screenRect.bottom - i.bottom)
        safeTop = baseSafe.top
    }

    fun screenBounds(): Rect = Rect(screenRect)

    /** where Leon's body may stand: inside the status bar / nav bar and above the keyboard */
    fun safe(): Rect {
        val r = Rect(baseSafe)
        val kbTop = behavior.keyboardTop()
        if (kbTop != null && kbTop < r.bottom) r.bottom = max(r.top + baseSize, kbTop)
        return r
    }

    // ------------------------------------------------------------------ window state

    /** keyboard is over Leon: fade to 20% and let touches fall through to the keys */
    fun setGhost(on: Boolean) {
        if (on == ghostOn) return
        ghostOn = on
        applyLeonWindow()
    }

    /** deep sleep: 60% size, 35% opacity, never touchable (does not disturb you) */
    fun setNightLook(on: Boolean) {
        if (on == nightOn) return
        nightOn = on
        applyLeonWindow()
    }

    fun applySize() {
        if (!ready) return
        baseSize = (prefs.sizeDp * density * 1.15f).toInt()
        applyLeonWindow()
    }

    private fun applyLeonWindow() {
        if (!ready) return
        var flags = baseFlags
        var alpha = 1f
        if (ghostOn) { flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; alpha = 0.2f }
        if (nightOn) { flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; alpha = 0.35f }
        val size = if (nightOn) (baseSize * 0.6f).toInt() else baseSize
        leonLp.flags = flags
        leonLp.alpha = alpha
        leonLp.width = size
        leonLp.height = size
        behavior.winSize = size
        lastX = Int.MIN_VALUE
        safeUpdate(leonView, leonLp)
    }

    private fun syncWindow() {
        val nx = behavior.x.toInt()
        val ny = behavior.y.toInt()
        if (nx != lastX || ny != lastY) {
            leonLp.x = nx
            leonLp.y = ny
            safeUpdate(leonView, leonLp)
            lastX = nx
            lastY = ny
        }
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try {
            if (v.isAttachedToWindow) wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // view already removed
        }
    }

    // ------------------------------------------------------------------ touch

    private fun installTouch() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (!dragging) behavior.onTap()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                behavior.onDoubleTap()
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                if (!dragging) {
                    leonView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    behavior.onLongPress()
                }
            }
        })
        leonView.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = behavior.x.toInt(); startY = behavior.y.toInt()
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) {
                        dragging = true
                        behavior.onDragStart()
                    }
                    if (dragging) behavior.onDragMove(startX + dx, startY + dy)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        behavior.onDragEnd()
                    }
                }
            }
            true
        }
    }

    fun openChat() {
        try {
            startActivity(Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } catch (e: Exception) {
            // blocked by the system; the notification still opens the app
        }
    }

    // ------------------------------------------------------------------ frame loop (30 fps busy, 10 fps idle, paused when screen is off)

    private val frame = object : Runnable {
        override fun run() {
            if (!running || !ready) return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastFrame).coerceIn(1L, 200L)
            lastFrame = now
            behavior.update(dt)
            behavior.applyVisual()
            syncWindow()
            fx.step(dt)
            leonView.invalidate()
            val active = fx.needsFrames()
            if (active || fxWasActive) fx.invalidate() // one extra redraw so a hidden bubble is really erased
            fxWasActive = active
            handler.postDelayed(this, behavior.frameDelayMs())
        }
    }

    private fun resumeLoop() {
        if (!ready) return
        running = true
        lastFrame = SystemClock.uptimeMillis()
        handler.removeCallbacks(frame)
        handler.post(frame)
    }

    private fun pauseLoop() {
        running = false
        handler.removeCallbacks(frame)
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (!ready) return
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    behavior.onScreenOff()
                    fx.invalidate()
                    pauseLoop()
                }
                Intent.ACTION_SCREEN_ON -> {
                    behavior.onScreenOn()
                    resumeLoop()
                }
            }
        }
    }

    // ------------------------------------------------------------------ notification

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Leon", NotificationManager.IMPORTANCE_MIN)
        ch.description = "Keeps Leon floating on your screen"
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)

        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        fun action(a: String, label: String): Notification.Action {
            val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, LeonOverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
            return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_leon), label, pi).build()
        }
        val muted = prefs.muted
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leon)
            .setContentTitle("Leon is floating on your screen")
            .setContentText(if (muted) "He is muted... and a little sad." else "Double-tap him to chat. Long-press = mute.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action(ACTION_MUTE_TOGGLE, if (muted) "Unmute Leon" else "Mute Leon"))
            .addAction(action(ACTION_STOP, "Stop Leon"))
            .build()
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
    }

    fun updateNotification() {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (e: Exception) {
            // notifications blocked: nothing to update
        }
    }
}
