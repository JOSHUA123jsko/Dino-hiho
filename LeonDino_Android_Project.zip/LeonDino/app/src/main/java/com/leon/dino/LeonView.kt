package com.leon.dino

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** The touchable window: just Leon's body sprite (squash / stretch / tilt come from LeonBehavior). Opaque on purpose. */
class LeonView(ctx: Context, private val sprites: Sprites) : View(ctx) {
    private var sprite = "happy"
    private var flip = false
    private var sx = 1f
    private var sy = 1f
    private var rot = 0f
    private var dy = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    fun set(sprite: String, flip: Boolean, sx: Float, sy: Float, rot: Float, dy: Float) {
        this.sprite = sprite
        this.flip = flip
        this.sx = sx
        this.sy = sy
        this.rot = rot
        this.dy = dy
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = sprites.body(sprite) ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val scale = min(w / bmp.width, h / bmp.height) * 0.9f
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        canvas.save()
        canvas.translate(w / 2f, h * 0.97f + dy)          // pivot at his feet
        canvas.rotate(rot)
        canvas.scale(if (flip) -sx else sx, sy)
        dst.set(-dw / 2f, -dh, dw / 2f, 0f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }
}
