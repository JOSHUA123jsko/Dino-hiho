package com.leon.dino

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Optional voice using the phone's own text-to-speech engine (works offline if an offline voice is installed). */
class LeonVoice(private val ctx: Context, private val prefs: Prefs) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var started = false

    fun speak(text: String) {
        if (!prefs.voice) return
        val clean = text
            .replace(Regex("[\\(\\[\\*].*?[\\)\\]\\*]"), " ")      // (stage directions) [notes] *sniff*
            .replace(Regex("[^\\p{L}\\p{N}\\s.,!?'-]"), " ")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
        if (clean.isEmpty()) return
        ensure()
        if (ready) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "leon")
    }

    private fun ensure() {
        if (started) return
        started = true
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                val r = t.setLanguage(Locale("fil", "PH"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.US)
                t.setPitch(1.35f)       // cute dino pitch
                t.setSpeechRate(1.1f)
                ready = true
            }
        }
    }

    fun stop() { tts?.stop() }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        started = false
    }
}
