package com.leon.dino

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Setup + settings screen. Built in code (no layout files, no libraries) so there is nothing to break. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var tvOverlay: TextView
    private lateinit var tvA11y: TextView
    private lateinit var btnToggle: Button
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, bold: Boolean = false, color: Int = 0xFF2A3550.toInt()): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(6), 0, dp(2))
        return tv
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun seekRow(
        parent: LinearLayout, title: String, min: Int, max: Int,
        get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String
    ) {
        val tv = label("", 14f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = get().coerceIn(min, max) - min
        fun upd(v: Int) { tv.text = title + ": " + fmt(v) }
        upd(get())
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                upd(v)
                if (fromUser) set(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun switchRow(parent: LinearLayout, title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = title
        sw.textSize = 14f
        sw.isChecked = get()
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.setOnCheckedChangeListener { _, checked -> set(checked) }
        parent.addView(sw)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(18), dp(18), dp(28))
        val sv = ScrollView(this)
        sv.addView(root)

        root.addView(label("Leon the Dino \uD83E\uDD96", 26f, true))
        root.addView(label("Your floating, talkative, math-and-science dino. 100% offline: this app has no internet permission and no cloud AI.", 13f, false, 0xFF667085.toInt()))

        root.addView(label("Setup", 18f, true))
        tvOverlay = label("", 14f)
        root.addView(tvOverlay)
        root.addView(button("1. Allow floating over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        tvA11y = label("", 14f)
        root.addView(tvA11y)
        root.addView(button("2. Let Leon touch text (read-only)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(label(
            "Leon can only READ the text he touches. He can never type, edit, delete or tap anything, and he skips password fields. " +
                "Nothing is saved or sent. If the switch is greyed out on Android 13+: App info > \u22EE > Allow restricted settings.",
            12f, false, 0xFF667085.toInt()
        ))
        btnToggle = button("") { toggle() }
        root.addView(btnToggle)
        root.addView(button("\uD83D\uDCAC Chat with Leon") { startActivity(Intent(this, ChatActivity::class.java)) })
        root.addView(label("On screen: drag = carry him \u00B7 tap = poke \u00B7 double-tap = chat \u00B7 long-press = mute / unmute (he will cry).", 12f, false, 0xFF667085.toInt()))

        root.addView(label("Personality & behavior", 18f, true))
        seekRow(root, "Gets bored after", 1, 60, { prefs.boredMinutes }, { prefs.boredMinutes = it }) { "$it min of no attention" }
        seekRow(root, "Chattiness (talks on his own)", 0, 100, { prefs.chattiness }, { prefs.chattiness = it }) { "$it%" }
        seekRow(root, "Curiosity (walks over to touch text)", 0, 100, { prefs.curiosity }, { prefs.curiosity = it }) { "$it%" }
        seekRow(root, "Size", 64, 160, { prefs.sizeDp }, {
            prefs.sizeDp = it
            LeonOverlayService.live()?.applySize()
        }) { "$it dp" }
        seekRow(root, "Deep sleep starts", 0, 23, { prefs.nightStart }, { prefs.nightStart = it }) { "$it:00" }
        seekRow(root, "Deep sleep ends (wakes up)", 0, 23, { prefs.nightEnd }, { prefs.nightEnd = it }) { "$it:00" }

        switchRow(root, "Mute Leon", { prefs.muted }, { v ->
            val live = LeonOverlayService.live()
            if (live != null) {
                live.behavior.setMuted(v)
            } else {
                prefs.muted = v
            }
        })
        switchRow(root, "Leon's voice (phone's own offline text-to-speech)", { prefs.voice }, { prefs.voice = it })
        switchRow(root, "Touch text on screen (read-only)", { prefs.readText }, { prefs.readText = it })
        switchRow(root, "Show the text he is holding (off = blurred bars)", { prefs.showHeldText }, { prefs.showHeldText = it })
        switchRow(root, "Also let him touch text boxes I type in", { prefs.readEditable }, { prefs.readEditable = it })
        switchRow(root, "Clean mode (no curse words)", { prefs.cleanMode }, {
            prefs.cleanMode = it
            (application as LeonApp).brain.cleanMode = it
        })
        switchRow(root, "Start Leon when the phone turns on", { prefs.autostart }, { prefs.autostart = it })

        root.addView(label("Apps Leon must never read (package names, comma separated)", 14f, true))
        val blocked = EditText(this)
        blocked.setText(prefs.blocked)
        blocked.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        blocked.textSize = 12f
        root.addView(blocked)
        root.addView(button("Save blocked apps") {
            prefs.blocked = blocked.text.toString()
            Toast.makeText(this, "Saved. Leon will skip those apps.", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Make Leon forget my name and favourites") {
            (application as LeonApp).brain.forgetMe()
            Toast.makeText(this, "Leon forgot everything about you (except the jokes).", Toast.LENGTH_SHORT).show()
        })
        root.addView(label("Sleep rules: a 5-minute nap after every 6 hours awake, deep sleep from 12 AM to 5 AM (adjustable above). While asleep he does not move, speak or make sounds.", 12f, false, 0xFF667085.toInt()))
        return sv
    }

    private fun refresh() {
        tvOverlay.text = if (Settings.canDrawOverlays(this)) "\u2705 Floating over other apps: allowed"
        else "\u274C Floating over other apps: not allowed yet"
        tvA11y.text = if (a11yOn()) "\u2705 Text touching (read-only accessibility): on"
        else "\u26AA Text touching: off. Leon still wanders, sleeps and chats."
        btnToggle.text = if (LeonOverlayService.isRunning()) "\uD83D\uDE34 Send Leon to sleep (stop)" else "\uD83E\uDD96 Wake Leon up!"
    }

    private fun a11yOn(): Boolean {
        if (ScreenReaderService.isEnabled()) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun toggle() {
        if (LeonOverlayService.isRunning()) {
            LeonOverlayService.stop(this)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow floating over other apps first (step 1).", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            LeonOverlayService.start(this)
        }
        handler.postDelayed({ refresh() }, 700L)
    }
}
