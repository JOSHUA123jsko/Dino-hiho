package com.leon.dino

import android.content.Context
import android.content.SharedPreferences

/** All of Leon's settings. Plain private storage on the phone, nothing else. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("leon_prefs", Context.MODE_PRIVATE)

    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    /** minutes without touching Leon before he gets bored (default 15) */
    var boredMinutes: Int
        get() = int("boredMinutes", 15)
        set(v) = putI("boredMinutes", v)

    /** 0..100: how often he talks on his own */
    var chattiness: Int
        get() = int("chattiness", 40)
        set(v) = putI("chattiness", v)

    /** 0..100: chance each wander decision becomes "go touch some text" */
    var curiosity: Int
        get() = int("curiosity", 15)
        set(v) = putI("curiosity", v)

    var sizeDp: Int
        get() = int("sizeDp", 96)
        set(v) = putI("sizeDp", v)

    /** speak with the phone's own text-to-speech (offline voices only) */
    var voice: Boolean
        get() = bool("voice", false)
        set(v) = putB("voice", v)

    /** show the text Leon is holding in his hands (off = shows blurred bars) */
    var showHeldText: Boolean
        get() = bool("showHeldText", true)
        set(v) = putB("showHeldText", v)

    /** master switch for touching on-screen text */
    var readText: Boolean
        get() = bool("readText", true)
        set(v) = putB("readText", v)

    /** also allow text boxes you type in (password fields are ALWAYS skipped) */
    var readEditable: Boolean
        get() = bool("readEditable", false)
        set(v) = putB("readEditable", v)

    /** no curse words at all (putragis, tarantado, sira ulo, bruha) */
    var cleanMode: Boolean
        get() = bool("cleanMode", false)
        set(v) = putB("cleanMode", v)

    var muted: Boolean
        get() = bool("muted", false)
        set(v) = putB("muted", v)

    /** "Leon, I need silence for real": no begging, no notes, just parked */
    var silenceReal: Boolean
        get() = bool("silenceReal", false)
        set(v) = putB("silenceReal", v)

    var autostart: Boolean
        get() = bool("autostart", false)
        set(v) = putB("autostart", v)

    /** deep sleep window, local hours: default 0 (12 AM) to 5 (5 AM) */
    var nightStart: Int
        get() = int("nightStart", 0)
        set(v) = putI("nightStart", v)
    var nightEnd: Int
        get() = int("nightEnd", 5)
        set(v) = putI("nightEnd", v)

    /** a nap of [napMinutes] after every [napEveryHours] hours of awake time */
    var napEveryHours: Int
        get() = int("napEveryHours", 6)
        set(v) = putI("napEveryHours", v)
    var napMinutes: Int
        get() = int("napMinutes", 5)
        set(v) = putI("napMinutes", v)

    /** awake time since the last nap (ms) */
    var awakeMs: Long
        get() = sp.getLong("awakeMs", 0L)
        set(v) { sp.edit().putLong("awakeMs", v).apply() }

    var lastMuteRitual: Long
        get() = sp.getLong("lastMuteRitual", 0L)
        set(v) { sp.edit().putLong("lastMuteRitual", v).apply() }

    var posX: Int
        get() = int("posX", -1)
        set(v) = putI("posX", v)
    var posY: Int
        get() = int("posY", -1)
        set(v) = putI("posY", v)

    /** comma-separated package names Leon will never read (password managers, authenticators ...). Add your bank app here. */
    var blocked: String
        get() = sp.getString("blocked", DEFAULT_BLOCKED) ?: DEFAULT_BLOCKED
        set(v) { sp.edit().putString("blocked", v).apply() }

    fun blockedSet(): Set<String> = blocked.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    companion object {
        const val DEFAULT_BLOCKED =
            "com.x8bit.bitwarden,com.lastpass.lpandroid,com.agilebits.onepassword,com.onepassword.android," +
                "com.google.android.apps.authenticator2,com.authy.authy,com.azure.authenticator,com.dashlane,com.kunzisoft.keepass.free"
    }
}
