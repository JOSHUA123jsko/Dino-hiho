package com.leon.dino

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowInsets
import android.view.WindowManager

object ScreenMetrics {
    @Suppress("DEPRECATION")
    fun bounds(ctx: Context, wm: WindowManager): Rect {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = Rect(wm.currentWindowMetrics.bounds)
            // some phones hand a non-activity context an empty rect: fall back to the plain display size
            if (b.width() > 0 && b.height() > 0) return b
            val dm = ctx.resources.displayMetrics
            return Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    /** system bars + camera cutout, so Leon never walks over the status bar / nav bar */
    fun insets(ctx: Context, wm: WindowManager): Rect {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
                WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
            )
            if (i.top > 0 || i.bottom > 0 || i.left > 0 || i.right > 0) return Rect(i.left, i.top, i.right, i.bottom)
        }
        val res = ctx.resources
        fun dim(name: String): Int {
            val id = res.getIdentifier(name, "dimen", "android")
            return if (id > 0) res.getDimensionPixelSize(id) else 0
        }
        return Rect(0, dim("status_bar_height"), 0, dim("navigation_bar_height"))
    }
}
