package com.leon.dino

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * READ-ONLY. This service never calls performAction(), performGlobalAction(), dispatchGesture() or sets text,
 * and its XML config does not even request those abilities. All Leon can do is:
 *   1. find where the keyboard is (so he can step out of the way)
 *   2. find bounds of buttons / text (so he can walk around buttons and walk TO some text)
 *   3. read ONE text string when he actually touches it
 * Skipped always: password fields, text boxes with PIN/OTP/CVV-ish hints, Leon's own windows, and blocked apps.
 * Text is returned to the caller in memory only; nothing is logged, stored or sent.
 */
class ScreenReaderService : AccessibilityService() {

    interface Listener { fun onWindowsChanged() }

    class ScanResult(val textBoxes: List<Rect>, val blockers: List<Rect>)

    companion object {
        @Volatile var instance: ScreenReaderService? = null
        @Volatile var listener: Listener? = null
        private val SENSITIVE = Regex(
            "\\b(password|passcode|passwd|pin|otp|cvv|cvc|card number|security code|kontrasenya)\\b",
            RegexOption.IGNORE_CASE
        )

        fun isEnabled(): Boolean = instance != null
    }

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var prefs: Prefs? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val t = event?.eventType ?: return
        if (t == AccessibilityEvent.TYPE_WINDOWS_CHANGED || t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            listener?.onWindowsChanged()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        worker.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------ keyboard

    /** bounds of the on-screen keyboard if it is showing, else null (cheap: no node traversal) */
    fun keyboardBounds(): Rect? {
        val ws = try { windows } catch (e: Exception) { return null }
        var out: Rect? = null
        for (w in ws) {
            try {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    val r = Rect()
                    w.getBoundsInScreen(r)
                    if (!r.isEmpty) out = r
                }
            } finally {
                recycle(w)
            }
        }
        return out
    }

    // ------------------------------------------------------------ scans (off the main thread)

    /** bounds only: where text boxes and tappable things are. No text is kept. */
    fun scanAsync(cb: (ScanResult) -> Unit) {
        if (worker.isShutdown) { cb(ScanResult(emptyList(), emptyList())); return }
        worker.execute {
            val res = try { scanNow() } catch (e: Exception) { ScanResult(emptyList(), emptyList()) }
            main.post { cb(res) }
        }
    }

    /** the moment Leon touches something: read the ONE smallest text element under that point. */
    fun readTextAsync(x: Int, y: Int, cb: (String?) -> Unit) {
        if (worker.isShutdown) { cb(null); return }
        worker.execute {
            val t = try { readTextAt(x, y) } catch (e: Exception) { null }
            main.post { cb(t) }
        }
    }

    private fun scanNow(): ScanResult {
        val texts = ArrayList<Rect>()
        val blockers = ArrayList<Rect>()
        val dm = resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        val budget = intArrayOf(700)
        for (root in roots()) {
            walk(root, budget) { n ->
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() >= 8 && r.height() >= 8) {
                    val area = r.width().toLong() * r.height()
                    if (texts.size < 80 && area < screenArea * 0.6 && nodeText(n) != null) texts.add(Rect(r))
                    if (blockers.size < 150 && area < screenArea * 0.4 && (n.isClickable || n.isEditable || n.isCheckable)) blockers.add(Rect(r))
                }
            }
        }
        return ScanResult(texts, blockers)
    }

    private fun readTextAt(x: Int, y: Int): String? {
        var best: String? = null
        var bestArea = Long.MAX_VALUE
        val budget = intArrayOf(700)
        val r = Rect()
        for (root in roots()) {
            walk(root, budget) { n ->
                n.getBoundsInScreen(r)
                if (r.contains(x, y)) {
                    val area = r.width().toLong() * r.height()
                    if (area < bestArea) {
                        val t = nodeText(n)
                        if (t != null) { bestArea = area; best = t }
                    }
                }
            }
        }
        return best?.take(300)
    }

    // ------------------------------------------------------------ helpers

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                try {
                    if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) w.root?.let { out.add(it) }
                } finally {
                    recycle(w)
                }
            }
        } catch (e: Exception) {
            // fall through to the active window
        }
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private fun walk(root: AccessibilityNodeInfo, budget: IntArray, visit: (AccessibilityNodeInfo) -> Unit) {
        val blocked = prefs?.blockedSet() ?: emptySet()
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty() && budget[0] > 0) {
            val n = stack.removeAt(stack.size - 1)
            budget[0]--
            try {
                if (!n.isVisibleToUser) continue
                val pkg = n.packageName?.toString()
                if (pkg == packageName || (pkg != null && pkg in blocked)) continue
                visit(n)
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i)
                    if (c != null) stack.add(c)
                }
            } finally {
                recycle(n)
            }
        }
        for (n in stack) recycle(n)
    }

    /** the text of a node if Leon is allowed to touch it, else null */
    private fun nodeText(n: AccessibilityNodeInfo): String? {
        if (n.isPassword) return null
        val editable = n.isEditable
        if (editable) {
            if (prefs?.readEditable != true) return null
            val hint = (n.hintText?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
            if (SENSITIVE.containsMatchIn(hint)) return null
        }
        val t = n.text?.toString()
        if (!t.isNullOrBlank()) return t
        val desc = n.contentDescription?.toString()
        if (!desc.isNullOrBlank() && n.childCount == 0) return desc
        return null
    }

    @Suppress("DEPRECATION")
    private fun recycle(n: AccessibilityNodeInfo?) {
        try { n?.recycle() } catch (e: Exception) { /* already recycled / no-op on Android 13+ */ }
    }

    @Suppress("DEPRECATION")
    private fun recycle(w: AccessibilityWindowInfo?) {
        try { w?.recycle() } catch (e: Exception) { /* no-op on Android 13+ */ }
    }
}
