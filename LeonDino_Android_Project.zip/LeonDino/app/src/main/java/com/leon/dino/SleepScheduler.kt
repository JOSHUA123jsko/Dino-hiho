package com.leon.dino

import java.util.Calendar

/** Leon's sleep rules: deep sleep 12 AM-5 AM, and a 5-minute nap after every 6 hours awake. */
class SleepScheduler(private val prefs: Prefs) {
    fun nightNow(cal: Calendar = Calendar.getInstance()): Boolean {
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val s = prefs.nightStart
        val e = prefs.nightEnd
        return when {
            s == e -> false
            s < e -> h >= s && h < e
            else -> h >= s || h < e // window that wraps past midnight, e.g. 22 -> 6
        }
    }

    fun napDue(awakeMs: Long): Boolean = awakeMs >= prefs.napEveryHours * 3_600_000L
}
