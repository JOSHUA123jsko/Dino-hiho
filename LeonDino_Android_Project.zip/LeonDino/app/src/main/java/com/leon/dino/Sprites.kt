package com.leon.dino

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

/** Loads Leon's art (cut out of your two character sheets) from assets/leon, lazily. */
class Sprites(private val ctx: Context) {
    private val cache = HashMap<String, Bitmap>()
    private val missing = HashSet<String>()

    /** full body: happy angry sad excited shy surprised sleepy thinking pouty love */
    fun body(name: String): Bitmap? = load("leon/body_$name.png")

    /** head+chest stickers (25): happy laughing angry sad excited shy surprised sleepy thinking pouty love kiss wink
     *  embarrassed proud scared tired hurt cool scream cheerful hungry confused begging goodbye */
    fun emote(name: String): Bitmap? = load("leon/emote_$name.png")

    private fun load(path: String): Bitmap? {
        cache[path]?.let { return it }
        if (path in missing) return null
        return try {
            val bmp = ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }
            if (bmp == null) {
                missing.add(path)
                null
            } else {
                cache[path] = bmp
                bmp
            }
        } catch (e: Exception) {
            missing.add(path)
            null
        }
    }
}
