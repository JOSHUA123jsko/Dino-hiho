package com.leon.dino.brain

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Topic(val keys: List<String>, val text: String)

/** Leon's phrasebook (assets/leon_content.json, generated from ai/leon_content.py). */
class Content(ctx: Context) {
    private val root: JSONObject = JSONObject(
        ctx.assets.open("leon_content.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    )

    private fun strings(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) out.add(a.getString(i))
        return out
    }

    fun list(key: String): List<String> = strings(root.optJSONArray(key))
    fun group(group: String, key: String): List<String> = strings(root.optJSONObject(group)?.optJSONArray(key))
    fun replies(intent: String): List<String> = group("replies", intent)
    fun tips(kind: String): List<String> = group("tips", kind)
    fun word(group: String, key: String): String = root.optJSONObject(group)?.optString(key, "") ?: ""

    val curses: List<String> = list("curses")
    val nicknames: List<String> = list("nicknames")
    val politeMarkers: Set<String> = list("polite_markers").toSet()
    val serious: Set<String> = list("serious").toSet()
    val affirm: Set<String> = list("affirm").toSet()
    val deny: Set<String> = list("deny").toSet()
    val filler: Set<String> = list("filler").toSet()
    val crisisPatterns: List<String> = list("crisis_patterns")
    val silencePatterns: List<String> = list("silence_patterns")

    val topics: List<Topic> = run {
        val a = root.optJSONArray("topics")
        val out = ArrayList<Topic>()
        if (a != null) {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Topic(strings(o.optJSONArray("keys")), o.optString("text")))
            }
        }
        out
    }

    val rules: List<Pair<String, List<String>>> = run {
        val a = root.optJSONArray("rules")
        val out = ArrayList<Pair<String, List<String>>>()
        if (a != null) {
            for (i in 0 until a.length()) {
                val r = a.getJSONArray(i)
                out.add(Pair(r.getString(0), strings(r.getJSONArray(1))))
            }
        }
        out
    }
}
