package com.leon.dino.brain

import android.content.Context
import org.json.JSONObject
import java.util.Locale
import kotlin.math.exp
import kotlin.math.sqrt

class Prediction(val intent: String, val confidence: Float)

/**
 * Leon's own trained model (ai/train_leon_model.py -> assets/leon_model.json).
 * Averaged perceptron over word + word-bigram + char-trigram features. Tokenizer and features
 * MUST stay identical to the Python trainer.
 */
class IntentModel(ctx: Context) {
    private val classes: List<String>
    private val tau: Float
    private val threshold: Float
    private val unknown: String
    private val featIdx = HashMap<String, IntArray>()
    private val featW = HashMap<String, FloatArray>()

    init {
        val json = JSONObject(
            ctx.assets.open("leon_model.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        )
        val cls = json.getJSONArray("classes")
        classes = (0 until cls.length()).map { cls.getString(it) }
        tau = json.optDouble("tau", 0.2).toFloat()
        threshold = json.optDouble("threshold", 0.6).toFloat()
        unknown = json.optString("unknown_class", "unknown")
        val feat = json.getJSONObject("feat")
        val keys = feat.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val arr = feat.getJSONArray(k)
            val idx = IntArray(arr.length())
            val w = FloatArray(arr.length())
            for (i in 0 until arr.length()) {
                val p = arr.getJSONArray(i)
                idx[i] = p.getInt(0)
                w[i] = p.getDouble(1).toFloat()
            }
            featIdx[k] = idx
            featW[k] = w
        }
    }

    fun classify(text: String): Prediction {
        val feats = features(text)
        if (feats.isEmpty()) return Prediction(unknown, 0f)
        val n = 1.0f / sqrt(feats.size.toFloat())
        val sc = FloatArray(classes.size)
        for (f in feats) {
            val idx = featIdx[f] ?: continue
            val w = featW[f] ?: continue
            for (i in idx.indices) sc[idx[i]] += w[i] * n
        }
        var best = 0
        for (i in sc.indices) if (sc[i] > sc[best]) best = i
        val m = sc[best]
        var z = 0f
        val e = FloatArray(sc.size)
        for (i in sc.indices) {
            e[i] = exp(((sc[i] - m) / tau).toDouble()).toFloat()
            z += e[i]
        }
        val p = e[best] / z
        return if (p >= threshold) Prediction(classes[best], p) else Prediction(unknown, p)
    }

    companion object {
        fun tokens(text: String): List<String> {
            val sb = StringBuilder(text.length)
            for (ch in text.lowercase(Locale.ROOT)) sb.append(if (Character.isLetterOrDigit(ch)) ch else ' ')
            return sb.toString().split(' ').filter { it.isNotEmpty() }
        }

        fun features(text: String): Set<String> {
            val toks = tokens(text)
            val f = LinkedHashSet<String>()
            for (t in toks) {
                f.add("w:$t")
                if (t.length >= 3) {
                    val p = "^" + t + "\$"
                    for (i in 0..(p.length - 3)) f.add("c:" + p.substring(i, i + 3))
                }
            }
            for (i in 0 until toks.size - 1) f.add("b:" + toks[i] + "_" + toks[i + 1])
            return f
        }
    }
}
