package com.leon.dino.brain

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Leon's offline brain. No network, no API: keyword rules + his own trained intent model + a phrasebook,
 * all shaped by the character-bible rules (yarn, po/opo, curses only as exclamations, read-the-room).
 */
class LeonBrain(ctx: Context) {
    private val content = Content(ctx)
    private val model = IntentModel(ctx)
    private val memory = Memory(ctx)
    private val picker = Picker()

    private enum class Awaiting { NONE, COMFORT_CHOICE }
    private var awaiting = Awaiting.NONE
    private var politeTurns = 0

    /** Set from the app's "clean mode" switch: no curse words at all. */
    @Volatile
    var cleanMode = false

    // intent -> (body sprite, bust sticker)
    private val look: Map<String, Pair<String, String?>> = mapOf(
        "greet" to Pair("happy", "cheerful"),
        "bye" to Pair("shy", "goodbye"),
        "goodnight" to Pair("sleepy", "sleepy"),
        "how_are_you" to Pair("happy", "cheerful"),
        "who_are_you" to Pair("happy", "proud"),
        "ai_question" to Pair("thinking", "cool"),
        "thanks" to Pair("love", "love"),
        "sorry" to Pair("shy", "embarrassed"),
        "praise" to Pair("love", "kiss"),
        "tease" to Pair("pouty", "pouty"),
        "noisy" to Pair("shy", "embarrassed"),
        "sad" to Pair("sad", "sad"),
        "lonely" to Pair("sad", "hurt"),
        "tired" to Pair("sleepy", "tired"),
        "stressed" to Pair("thinking", "scared"),
        "angry" to Pair("thinking", "hurt"),
        "bored" to Pair("pouty", "pouty"),
        "happy_share" to Pair("excited", "excited"),
        "joke" to Pair("excited", "laughing"),
        "quote" to Pair("thinking", "proud"),
        "fact" to Pair("thinking", "surprised"),
        "explain" to Pair("thinking", "thinking"),
        "math_help" to Pair("thinking", "cool"),
        "food" to Pair("excited", "hungry"),
        "time" to Pair("happy", "wink"),
        "date" to Pair("happy", "wink"),
        "sleep_info" to Pair("sleepy", "sleepy"),
        "help" to Pair("happy", "cheerful"),
        "chat_prompt" to Pair("happy", "wink"),
        "affirm" to Pair("excited", "cheerful"),
        "deny" to Pair("shy", null),
        "unknown" to Pair("thinking", "confused")
    )

    // ------------------------------------------------------------------ public API

    /** Main entry: what does Leon say to this message? */
    fun reply(raw: String): Reply {
        val text = raw.trim()
        if (text.isEmpty()) return Reply(listOf("Hmm? Wala akong narinig, yarn."), "thinking", "confused")
        val lower = text.lowercase(Locale.ROOT)
        val toks = IntentModel.tokens(text)
        val joined = toks.joinToString(" ")

        if (toks.any { it in content.politeMarkers }) politeTurns = 6 else if (politeTurns > 0) politeTurns--
        memory.trust = minOf(20, memory.trust + 1)

        // 0) safety first: no jokes, real numbers
        if (content.crisisPatterns.any { lower.contains(it) }) return crisis()

        // 1) the fail-safe: "Leon, I need silence for real"
        if (content.silencePatterns.any { lower.contains(it) }) {
            awaiting = Awaiting.NONE
            return Reply(emptyList(), "sad", "sad", Action.SILENCE_REAL, true)
        }

        // 2) answer to a question Leon just asked
        if (awaiting == Awaiting.COMFORT_CHOICE) {
            awaiting = Awaiting.NONE
            comfortChoice(joined)?.let { return it }
        }

        // 3) small things to remember
        memory.extractName(lower)?.let { n ->
            memory.name = n
            val t = picker.pick("m:name", content.group("memory", "name_set")) ?: "Sige, {name}, yarn."
            return Reply(listOf(finish(render(t))), "happy", "cheerful")
        }
        memory.extractFood(lower)?.let { f ->
            memory.food = f
            val t = picker.pick("m:food", content.group("memory", "food_set")) ?: "Noted, yarn."
            return Reply(listOf(finish(render(t, mapOf("food" to f)))), "excited", "hungry")
        }

        // 4) math
        MathSolver.detect(text)?.let { return mathReply(it) }

        // 5) plain yes / no
        val core = toks.filter { it !in content.filler }.joinToString(" ")
        if (core in content.affirm) return say("affirm")
        if (core in content.deny) return say("deny")

        // 6) rules first, then his trained model
        val intent = ruleIntent(toks, joined) ?: model.classify(text).intent
        return compose(intent, joined)
    }

    fun quote(): String = picker.pick("quotes", content.list("quotes")) ?: "Math is just feelings with rules, yarn."
    fun muteQuote(): String = picker.pick("mquotes", content.list("mute_quotes")) ?: quote()
    fun joke(): String = picker.pick("jokes", content.list("jokes")) ?: "Bakit malungkot ang math book? Kasi andami niyang problems, yarn."
    fun fact(): String = picker.pick("facts", content.list("facts")) ?: "Ang 0.999... ay eksaktong 1, yarn."

    fun poke(): String = rootLine("poke")
    fun dragLine(): String = rootLine("drag")
    fun dropLine(): String = rootLine("drop")
    fun chatter(): String = if (Random.nextInt(100) < 35) quote() else rootLine("chatter")
    fun greeting(): String = finish(render("{tod} {name}! Si Leon 'to, yarn."))

    /** A line from a named group of the phrasebook: boredom.s1, mute.beg, sleep.nap_start, text.throw ... */
    fun line(group: String, key: String): String {
        val pool = content.group(group, key)
        val t = pickTemplate("$group.$key", pool, false) ?: return ""
        return finish(render(t))
    }

    /** Leon's comment about the text he is holding. Never echoes the text itself. */
    fun textReaction(text: String?): String = line("text", kindOf(text))

    fun kindOf(text: String?): String {
        if (text.isNullOrBlank()) return "generic"
        val t = text.trim()
        return when {
            Regex("[\\w.+-]+@[\\w-]+\\.[\\w.]+").containsMatchIn(t) -> "email"
            t.contains("http", true) || t.contains("www.", true) -> "url"
            Regex("\\d\\s*[+\\-*/^=×÷]\\s*\\d").containsMatchIn(t) -> "math"
            t.endsWith("?") -> "question"
            Regex("^[\\d.,:\\s%]+$").matches(t) -> "number"
            t.length > 80 -> "long"
            t.length <= 12 -> "short"
            else -> "generic"
        }
    }

    fun forgetMe() = memory.forgetAll()

    // ------------------------------------------------------------------ internals

    private fun crisis(): Reply {
        awaiting = Awaiting.NONE
        return Reply(content.list("crisis"), "sad", "hurt", Action.NONE, true)
    }

    private fun compose(intent: String, joined: String): Reply = when (intent) {
        "mute_playful" -> Reply(emptyList(), "sad", "begging", Action.MUTE)
        "unmute" -> Reply(emptyList(), "shy", "kiss", Action.UNMUTE)
        "noisy" -> say("noisy", action = Action.CHATTY_DOWN)
        "explain" -> explain(joined)
        "sad", "lonely" -> comfort(intent)
        "tired" -> say("tired", mapOf("tip" to (picker.pick("tip:tired", content.tips("tired")) ?: "")))
        "stressed" -> say("stressed", mapOf("tip" to (picker.pick("tip:stressed", content.tips("stressed")) ?: "")))
        else -> say(intent)
    }

    private fun say(intent: String, extra: Map<String, String> = emptyMap(), action: Action = Action.NONE): Reply {
        val (mood, emote) = look[intent] ?: Pair("happy", null)
        val serious = intent in content.serious
        val t = pickTemplate("rep:$intent", content.replies(intent), serious)
        if (t == null) return if (intent != "unknown") say("unknown") else Reply(emptyList(), mood, emote, action, serious)
        return Reply(listOf(finish(render(t, extra), serious)), mood, emote, action, serious)
    }

    private fun comfort(intent: String): Reply {
        val base = say(intent)
        val follow = picker.pick("follow", content.list("follow_comfort"))?.let { finish(it, true) }
        awaiting = Awaiting.COMFORT_CHOICE
        return base.copy(lines = base.lines + listOfNotNull(follow))
    }

    private fun comfortChoice(joined: String): Reply? {
        fun has(vararg w: String) = w.any { joined.contains(it) }
        return when {
            has("comfort", "makinig", "samahan", "yakap", "listen") ->
                say("choice_comfort").copy(mood = "love", emote = "love", serious = true)
            has("explain", "explanation", "ipaliwanag", "advice", "solution", "tips", "dahilan") -> {
                val base = say("choice_explain")
                val tip = picker.pick("tip:stressed", content.tips("stressed"))?.let { finish(it) }
                base.copy(mood = "thinking", emote = "thinking", lines = base.lines + listOfNotNull(tip))
            }
            has("joke", "patawa", "patawanin", "distract") -> say("choice_joke").copy(mood = "excited", emote = "laughing")
            else -> null
        }
    }

    private fun explain(joined: String): Reply {
        val t = findTopic(joined)
        return if (t != null) Reply(listOf(finish(t.text)), "thinking", "thinking") else say("unknown")
    }

    private fun findTopic(joined: String): Topic? {
        val padded = " $joined "
        for (t in content.topics) {
            for (k in t.keys) {
                val kk = IntentModel.tokens(k).joinToString(" ")
                if (kk.isNotEmpty() && padded.contains(" $kk ")) return t
            }
        }
        return null
    }

    private fun ruleIntent(toks: List<String>, joined: String): String? {
        val padded = " $joined "
        for ((intent, kws) in content.rules) {
            for (kw in kws) {
                if (kw.endsWith("*")) {
                    val p = kw.dropLast(1)
                    if (toks.any { it.startsWith(p) }) return intent
                } else {
                    val k = IntentModel.tokens(kw).joinToString(" ")
                    if (k.isEmpty()) continue
                    if (k.contains(' ')) {
                        if (padded.contains(" $k ")) return intent
                    } else if (k in toks) return intent
                }
            }
        }
        if (findTopic(joined) != null) return "explain"
        return null
    }

    private fun mathReply(m: MathFound): Reply {
        val g = "math"
        return when (m) {
            is MathFound.Calc -> {
                val t = picker.pick("m:calc", content.group(g, "result")) ?: "{x} = {result}, yarn."
                Reply(listOf(finish(t.replace("{x}", m.expr).replace("{result}", MathSolver.format(m.value)))), "thinking", "cool")
            }
            is MathFound.Percent -> {
                val t = picker.pick("m:pct", content.group(g, "percent")) ?: "{result}, yarn."
                Reply(listOf(finish(t.replace("{result}", MathSolver.format(m.value)))), "thinking", "proud")
            }
            is MathFound.Split -> {
                val t = picker.pick("m:split", content.group(g, "split")) ?: "{result} bawat isa, yarn."
                Reply(listOf(finish(t.replace("{result}", MathSolver.format(m.share)))), "happy", "cheerful")
            }
            is MathFound.DivZero -> {
                val t = picker.pick("m:div0", content.group(g, "div0")) ?: "Hindi pwedeng i-divide sa zero, yarn."
                Reply(listOf(finish(t)), "surprised", "scared")
            }
        }
    }

    // ---- templates, slots, voice rules

    private fun blockCurse(serious: Boolean) = serious || cleanMode || politeTurns > 0

    private fun pickTemplate(key: String, pool: List<String>, serious: Boolean): String? {
        val block = blockCurse(serious)
        val trusted = memory.trust >= 6
        val raw = picker.pick(key, pool) { t ->
            (trusted || !t.startsWith("[trust]")) && (!block || !Style.containsCurse(t, content.curses))
        } ?: picker.pick(key, pool) { t -> trusted || !t.startsWith("[trust]") } ?: return null
        return raw.removePrefix("[trust]").removePrefix("!c")
    }

    private fun finish(s: String, serious: Boolean = false): String {
        var out = Style.tidy(s)
        if (blockCurse(serious)) out = Style.sanitize(out, content.curses)
        return Style.withYarn(out)
    }

    private fun rootLine(key: String): String {
        val t = pickTemplate(key, content.list(key), false) ?: return ""
        return finish(render(t))
    }

    private fun render(template: String, extra: Map<String, String> = emptyMap()): String {
        var s = template
        for ((k, v) in extra) s = s.replace("{$k}", v)
        fun rep(k: String, f: () -> String) {
            val tag = "{$k}"
            if (s.contains(tag)) s = s.replace(tag, f())
        }
        rep("po") { if (politeTurns > 0) " po" else "" }
        rep("Opo") { if (politeTurns > 0) "Opo" else "Oo" }
        rep("name") { memory.name.ifEmpty { picker.pick("nick", content.nicknames) ?: "boss" } }
        rep("tod") { todGreeting() }
        rep("quote") { quote() }
        rep("joke") { joke() }
        rep("fact") { fact() }
        rep("food") { food() }
        rep("time") { SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) }
        rep("date") { SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH).format(Date()) }
        return s.replace(Regex("\\{[A-Za-z]+\\}"), "")
    }

    private fun food(): String {
        val fav = memory.food
        if (fav.isNotEmpty() && Random.nextInt(100) < 40) return fav
        return picker.pick("foods", content.list("foods")) ?: "adobo"
    }

    private fun todGreeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val k = when {
            h in 5..10 -> "morning"
            h in 11..12 -> "noon"
            h in 13..17 -> "afternoon"
            h >= 18 -> "evening"
            else -> "late"
        }
        return content.word("tod", k)
    }
}
