package com.leon.dino.brain

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

sealed class MathFound {
    class Calc(val expr: String, val value: Double) : MathFound()
    class Percent(val pct: Double, val of: Double, val value: Double) : MathFound()
    class Split(val total: Double, val people: Int, val share: Double) : MathFound()
    class DivZero : MathFound()
}

/** Tiny offline calculator: + - * / ^ ( ) ! pi e sqrt abs sin cos tan ln log exp floor ceil round, "15% of 2000", "hatian 1250 sa 4". */
object MathSolver {
    private class MathError(msg: String) : Exception(msg)
    private class DivZeroError : Exception("div0")

    private val dateLike = Regex("\\d{1,4}\\s*-\\s*\\d{1,2}\\s*-\\s*\\d{1,4}")
    private val percentRx = Regex("(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:of|ng)\\s*(\\d+(?:\\.\\d+)?)")
    private val splitRx = Regex("(?:hati(?:an)?|split|divide)\\D{0,20}?(\\d+(?:\\.\\d+)?)\\D{1,15}?(\\d+)\\b")
    private val factorialRx = Regex("(?:factorial of|factorial ng)\\s*(\\d+)|(\\d+)\\s*factorial")
    private val bareFactorial = Regex("\\(?\\d+\\)?!+")
    private val funcCall = Regex("(sqrt|abs|sin|cos|tan|asin|acos|atan|ln|log|log2|exp|floor|ceil|round|fact)\\s*\\(")

    fun detect(raw: String): MathFound? {
        val t = raw.lowercase(Locale.ROOT).replace(Regex("(?<=\\d),(?=\\d{3})"), "")

        percentRx.find(t)?.let { m ->
            val p = m.groupValues[1].toDouble()
            val o = m.groupValues[2].toDouble()
            return MathFound.Percent(p, o, p / 100.0 * o)
        }
        splitRx.find(t)?.let { m ->
            val total = m.groupValues[1].toDouble()
            val n = m.groupValues[2].toInt()
            return if (n == 0) MathFound.DivZero() else MathFound.Split(total, n, total / n)
        }

        factorialRx.find(t)?.let { m ->
            val n = m.groupValues[1].ifEmpty { m.groupValues[2] }.toInt()
            if (n in 0..100) return MathFound.Calc("$n!", eval("$n!"))
        }

        val prepared = t.replace('×', '*').replace('÷', '/').replace("**", "^")
            .replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*")
        if (dateLike.containsMatchIn(prepared)) return null
        val words = prepared.split(Regex("\\s+")).filter { it.isNotEmpty() }
        for (i in words.indices) {
            for (j in words.size downTo i + 1) {
                var cand = words.subList(i, j).joinToString(" ").trimEnd('?', '.', ',', '=').trim()
                // "5!" is a factorial, but "what is 12*7!" is just excitement
                if (cand.endsWith("!") && !bareFactorial.matches(cand)) cand = cand.trimEnd('!')
                if (!looksMathy(cand)) continue
                try {
                    return MathFound.Calc(cand, eval(cand))
                } catch (e: DivZeroError) {
                    return MathFound.DivZero()
                } catch (e: Exception) {
                    // not a clean expression, keep looking at shorter / later pieces
                }
            }
        }
        return null
    }

    private fun looksMathy(s: String): Boolean {
        if (!s.any { it.isDigit() }) return false
        if (funcCall.containsMatchIn(s)) return true
        if (s.any { it == '*' || it == '/' || it == '^' || it == '+' || it == '!' }) return true
        return s.contains(" - ")
    }

    fun eval(expr: String): Double {
        val v = Parser(expr).parse()
        if (v.isNaN() || v.isInfinite()) throw MathError("not a number")
        return v
    }

    fun format(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "hindi ma-compute"
        if (abs(d) >= 1e15 || (abs(d) < 1e-6 && d != 0.0)) return String.format(Locale.US, "%.4e", d)
        return BigDecimal(d).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var pos = 0

        fun peek(): Char = if (pos < s.length) s[pos] else '\u0000'
        fun skipWs() { while (pos < s.length && s[pos] == ' ') pos++ }

        fun parse(): Double {
            val v = expr()
            skipWs()
            if (pos != s.length) throw MathError("trailing text")
            return v
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                skipWs()
                val c = peek()
                if (c == '+') { pos++; v += term() }
                else if (c == '-') { pos++; v -= term() }
                else break
            }
            return v
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                skipWs()
                val c = peek()
                if (c == '*') { pos++; v *= unary() }
                else if (c == '/') {
                    pos++
                    val d = unary()
                    if (d == 0.0) throw DivZeroError()
                    v /= d
                } else break
            }
            return v
        }

        fun unary(): Double {
            skipWs()
            val c = peek()
            if (c == '-') { pos++; return -unary() }
            if (c == '+') { pos++; return unary() }
            return power()
        }

        fun power(): Double {
            val b = postfix()
            skipWs()
            if (peek() == '^') {
                pos++
                val e = unary()
                return b.pow(e)
            }
            return b
        }

        fun postfix(): Double {
            var v = primary()
            while (true) {
                skipWs()
                if (peek() == '!') { pos++; v = factorial(v) } else break
            }
            return v
        }

        fun primary(): Double {
            skipWs()
            val c = peek()
            if (c == '(') {
                pos++
                val v = expr()
                skipWs()
                if (peek() != ')') throw MathError("missing )")
                pos++
                return v
            }
            if (c.isDigit() || c == '.') return number()
            if (c.isLetter()) {
                val name = ident()
                skipWs()
                if (peek() == '(') {
                    pos++
                    val a = expr()
                    skipWs()
                    if (peek() != ')') throw MathError("missing )")
                    pos++
                    return call(name, a)
                }
                return when (name) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    else -> throw MathError("unknown word: $name")
                }
            }
            throw MathError("unexpected character")
        }

        fun number(): Double {
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            return s.substring(start, pos).toDouble()
        }

        fun ident(): String {
            val start = pos
            while (pos < s.length && (s[pos].isLetterOrDigit())) pos++
            return s.substring(start, pos)
        }

        fun factorial(v: Double): Double {
            if (v < 0 || v != Math.floor(v) || v > 100) throw MathError("factorial needs 0..100")
            var r = 1.0
            for (i in 2..v.toInt()) r *= i
            return r
        }

        fun call(name: String, a: Double): Double = when (name) {
            "sqrt" -> if (a < 0) throw MathError("sqrt of negative") else Math.sqrt(a)
            "abs" -> abs(a)
            "sin" -> Math.sin(a)
            "cos" -> Math.cos(a)
            "tan" -> Math.tan(a)
            "asin" -> Math.asin(a)
            "acos" -> Math.acos(a)
            "atan" -> Math.atan(a)
            "ln" -> if (a <= 0) throw MathError("ln domain") else Math.log(a)
            "log" -> if (a <= 0) throw MathError("log domain") else Math.log10(a)
            "log2" -> if (a <= 0) throw MathError("log domain") else Math.log(a) / Math.log(2.0)
            "exp" -> Math.exp(a)
            "floor" -> Math.floor(a)
            "ceil" -> Math.ceil(a)
            "round" -> Math.rint(a)
            "fact" -> factorial(a)
            else -> throw MathError("unknown function: $name")
        }
    }
}
