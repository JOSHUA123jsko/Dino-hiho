package com.leon.dino.brain

import android.content.Context
import java.util.Locale

/** Leon remembers small things (your name, favourite food) in the phone's private storage. Nothing leaves the device. */
class Memory(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("leon_memory", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v).apply() }
    var food: String
        get() = sp.getString("food", "") ?: ""
        set(v) { sp.edit().putString("food", v).apply() }
    var trust: Int
        get() = sp.getInt("trust", 0)
        set(v) { sp.edit().putInt("trust", v).apply() }

    fun forgetAll() { sp.edit().clear().apply() }

    private val nameRx = Regex("(?:my name is|call me|ako si|tawagin mo akong|tawagin mo ako na|pangalan ko ay|pangalan ko si)\\s+([a-zñ][a-zñ'\\-]{1,14})")
    private val foodRx = Regex("(?:paborito ko ang|paborito ko ay|paborito ko|favorite food is|my favorite food is|favorite ko ang)\\s+([a-zñ\\-]{2,15}(?: [a-zñ\\-]{2,15})?)")
    private val stop = setOf("leon", "dino", "si", "ang", "po", "na", "ay", "ko", "mo", "yung", "yong")

    fun extractName(lower: String): String? {
        val m = nameRx.find(lower) ?: return null
        val w = m.groupValues[1]
        if (w in stop) return null
        return w.replaceFirstChar { it.titlecase(Locale.ROOT) }
    }

    fun extractFood(lower: String): String? {
        val m = foodRx.find(lower) ?: return null
        val f = m.groupValues[1].trim()
        if (f.split(" ").any { it in stop }) return null
        return f
    }
}
