package com.leon.dino.brain

import kotlin.random.Random

/** Things Leon's brain can ask the app to do (the app performs them, the brain never touches the OS). */
enum class Action { NONE, MUTE, UNMUTE, SILENCE_REAL, CHATTY_DOWN }

/** What Leon says back, plus how his body should react. */
data class Reply(
    val lines: List<String>,
    val mood: String = "happy",      // one of the 10 body sprites: happy angry sad excited shy surprised sleepy thinking pouty love
    val emote: String? = null,       // one of the 25 bust stickers (assets/leon/emote_<name>.png)
    val action: Action = Action.NONE,
    val serious: Boolean = false     // true = no jokes were used (comfort / crisis)
)

/** Picks random items but avoids repeating the last few, so Leon never sounds like a looping record. */
class Picker(private val rnd: Random = Random.Default) {
    private val recent = HashMap<String, ArrayDeque<Int>>()

    fun <T> pick(key: String, pool: List<T>, ok: (T) -> Boolean = { true }): T? {
        val all = pool.indices.filter { ok(pool[it]) }
        if (all.isEmpty()) return null
        val hist = recent.getOrPut(key) { ArrayDeque() }
        var cands = all.filter { it !in hist }
        if (cands.isEmpty()) {
            hist.clear()
            cands = all
        }
        val i = cands[rnd.nextInt(cands.size)]
        hist.addLast(i)
        while (hist.size > minOf(4, all.size / 2)) hist.removeFirst()
        return pool[i]
    }
}
