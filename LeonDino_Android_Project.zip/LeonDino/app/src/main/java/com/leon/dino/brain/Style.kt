package com.leon.dino.brain

/** Leon's voice rules from the character bible, as code. */
object Style {
    private val trailing = setOf('.', '!', '?', '…')

    /** "yarn" is punctuation: every normal line carries one, scream/stage-direction lines don't. */
    fun withYarn(line: String): String {
        val l = line.trim()
        if (l.isEmpty()) return l
        if (l.contains("yarn", ignoreCase = true)) return l
        if (l.startsWith("(") || l.startsWith("*") || l.startsWith("[") || l.startsWith(":")) return l
        if (l.none { it.isLowerCase() }) return l // SCREAMS and emoticons
        var end = l.length
        while (end > 0 && l[end - 1] in trailing) end--
        return l.substring(0, end) + ", yarn" + l.substring(end)
    }

    fun containsCurse(line: String, curses: List<String>): Boolean {
        val l = line.lowercase()
        return curses.any { l.contains(it) }
    }

    /** Clean mode / polite mode: swap the r-curses for a harmless Filipino exclamation. */
    fun sanitize(line: String, curses: List<String>): String {
        var out = line
        for (c in curses) {
            out = Regex(Regex.escape(c), RegexOption.IGNORE_CASE).replace(out) { m ->
                if (m.value.first().isUpperCase()) "Naku" else "naku"
            }
        }
        return out
    }

    fun tidy(s: String): String = s.replace(Regex("\\s{2,}"), " ").replace(" ,", ",").trim()
}
