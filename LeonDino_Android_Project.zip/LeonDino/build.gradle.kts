// Versions chosen as a matched set: Gradle 8.7 + AGP 8.5.2 + Kotlin 1.9.24 + JDK 17.
// If your Android Studio offers "Upgrade AGP", it is safe to accept.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
