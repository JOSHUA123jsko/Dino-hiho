#!/usr/bin/env bash
# Builds the debug APK (used by the GitHub Actions workflow, but also works on any Linux/Mac with JDK 17 + Android SDK 34).
# Output: out/Leon-the-Dino.apk   (and, best effort, a GitHub Release with a direct download link)
set -uo pipefail
cd "$(dirname "$0")/.."
OUT="${GITHUB_WORKSPACE:-$(pwd)}/out"
mkdir -p "$OUT"

fail() {
  {
    echo '### Build failed. Copy everything in the box below and send it to Claude.'
    echo '```'
    if [ -f build.log ]; then
      grep -E '^e: |error:|What went wrong|Execution failed' -A3 build.log | head -120
    else
      echo "(no build log: it failed before Gradle started)"
    fi
    echo '```'
  } >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
  echo "BUILD FAILED. Last lines of the log:"
  tail -n 60 build.log 2>/dev/null || true
  exit 1
}

# Android SDK: GitHub runners already have it; just accept licences and make sure platform 34 is there
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKM" ]; then
  yes | "$SDKM" --licenses > /dev/null 2>&1 || true
  "$SDKM" "platforms;android-34" "build-tools;34.0.0" > /dev/null 2>&1 || true
fi

# Gradle 8.7 (the workflow installs it; this is the fallback for other machines)
if ! command -v gradle > /dev/null 2>&1; then
  echo "gradle not found, downloading 8.7 ..."
  curl -fsSL https://services.gradle.org/distributions/gradle-8.7-bin.zip -o /tmp/gradle.zip || fail
  mkdir -p "$HOME/gradle-dist" && unzip -q -o /tmp/gradle.zip -d "$HOME/gradle-dist"
  export PATH="$HOME/gradle-dist/gradle-8.7/bin:$PATH"
fi

gradle assembleDebug --no-daemon --stacktrace 2>&1 | tee build.log
[ "${PIPESTATUS[0]}" -eq 0 ] || fail

APK="$(find app/build/outputs/apk/debug -name '*.apk' -print -quit 2>/dev/null)"
[ -n "$APK" ] || fail
cp "$APK" "$OUT/Leon-the-Dino.apk"
echo "APK ready: $OUT/Leon-the-Dino.apk"

# Best effort: also publish under Releases, so the phone gets one tap-to-download link
if command -v gh > /dev/null 2>&1 && [ -n "${GH_TOKEN:-}" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  gh release delete latest-build --cleanup-tag --yes --repo "$GITHUB_REPOSITORY" > /dev/null 2>&1 || true
  gh release create latest-build "$OUT/Leon-the-Dino.apk" --repo "$GITHUB_REPOSITORY" --prerelease \
    --title "Leon the Dino - latest build" \
    --notes "Tap Leon-the-Dino.apk to download it, then open it to install." \
    || echo "(Releases upload skipped; use the Artifacts download instead)"
fi
exit 0
