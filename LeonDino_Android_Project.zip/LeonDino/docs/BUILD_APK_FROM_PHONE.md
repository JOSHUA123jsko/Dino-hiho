# Get the Leon APK without a computer (about 10 minutes, free)

GitHub builds the app for you in the cloud. You only need the phone browser.

1. Make / log in to a free account at **github.com**. Tap **+ > New repository**, name it `leon-dino`, tap **Create repository**.
2. In the new repo: **Add file > Upload files** > choose **LeonDino_Android_Project.zip** (do NOT unzip it) > **Commit changes**.
3. **Add file > Create new file**. In the name box type exactly `.github/workflows/build-apk.yml`.
   Paste the whole text of **build-apk.yml** into the big box > **Commit changes**.
4. Open the **Actions** tab > **Build Leon APK**. Wait about 5-10 minutes for the green check.
5. Download the APK:
   - repo main page > **Releases** > **Leon the Dino - latest build** > tap **Leon-the-Dino.apk**, or
   - Actions > the finished run > **Artifacts** > **Leon-the-Dino-APK** (it is a zip with the apk inside).
6. Tap the downloaded APK. Allow **Install unknown apps** for your browser/Files app when asked, then **Install**
   (Play Protect may say it is unscanned: choose **Install anyway**, it is your own app).
7. Open **Leon the Dino**:
   1. **Allow floating over other apps**
   2. **Accessibility > Leon (read-only text touch) > On**. If the switch is greyed out: Settings > Apps > Leon the Dino > **⋮ > Allow restricted settings**, then try again.
   3. Tap **Wake Leon up!** (allow notifications if asked)
   Xiaomi/Oppo/Vivo/Realme/Samsung: also allow "Display pop-up windows while running in background" and set battery to Unrestricted.

Updating later: change files, push, wait for the new build, install the new APK over the old one
(all builds use the same signing key, so it installs as an update and keeps your settings).

## If the build shows a red X
Open the failed run > **Summary**. Copy the box that says "Build failed" and send it to Claude. That is all that is needed to fix it.

## With a computer instead
Unzip, open the `LeonDino` folder in Android Studio (JDK 17, SDK 34), press Run with the phone plugged in (USB debugging on).
Or from a terminal with Gradle 8.7 installed: `gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.

## Good to know
- The signing key in `app/leon-debug.keystore` is a personal-use key stored in the project. Keep the repo **Private** and never publish this build to Google Play.
- The APK is a debug build: fully functional, just not size-optimised.
