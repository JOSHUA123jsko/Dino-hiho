#!/usr/bin/env python3
"""
Cuts Leon's sprites out of the two character sheets (needs: pillow, numpy, scipy -- all offline).

  python3 make_sprites.py SHEET_10_EXPRESSIONS.png SHEET_25_EXPRESSIONS.png [OUT_DIR]

  OUT_DIR defaults to ../app/src/main/assets/leon
  -> body_<mood>.png   x10  clean full-body sprites (happy angry sad excited shy surprised sleepy thinking pouty love)
  -> emote_<name>.png  x25  head+chest stickers with a soft faded bottom

The grid positions below match the sheets you supplied (1312x1199). If you swap in different art,
adjust CELLS_10 / COL_X / ROW_LABEL_Y.
"""
import os, sys
import numpy as np
from PIL import Image
from scipy import ndimage as ndi


def segment(crop_rgb, thresh=95, grow=2, close_bottom=False):
    a = np.asarray(crop_rgb.convert('RGB')).astype(np.int32)
    lum = 0.299*a[...,0] + 0.587*a[...,1] + 0.114*a[...,2]
    dark = lum < thresh
    dark2 = ndi.binary_dilation(dark, iterations=grow)
    if close_bottom:
        dark2[-4:, :] = True
    free = ~dark2
    lab, n = ndi.label(free)
    border = set(np.unique(np.concatenate([lab[0,:], lab[-1,:], lab[:,0], lab[:,-1]])))
    border.discard(0)
    ext = np.isin(lab, list(border))
    interior = ~ext
    lab2, n2 = ndi.label(interior)
    if n2 == 0:
        return None
    sizes = ndi.sum(interior, lab2, range(1, n2+1))
    keep = 1 + int(np.argmax(sizes))
    mask = lab2 == keep
    mask = ndi.binary_erosion(mask, iterations=grow)
    mask = ndi.binary_fill_holes(mask)
    return mask, a

def to_rgba(a, mask, feather=0.9):
    # decontaminate edge colours: pull RGB from nearest solid-interior pixel
    core = ndi.binary_erosion(mask, iterations=2)
    idx = ndi.distance_transform_edt(~core, return_distances=False, return_indices=True)
    rgb = a[idx[0], idx[1]].astype(np.uint8)
    rgb = np.where(core[..., None], a.astype(np.uint8), rgb)
    alpha = ndi.gaussian_filter(mask.astype(np.float32), feather)
    alpha = np.clip((alpha - 0.5) * 1.6 + 0.5, 0, 1)
    out = np.dstack([rgb, (alpha * 255).astype(np.uint8)])
    return Image.fromarray(out, 'RGBA')

def trim(img, pad=3):
    bb = img.getchannel('A').point(lambda v: 255 if v > 8 else 0).getbbox()
    x0, y0, x1, y1 = bb
    return img.crop((max(0, x0-pad), max(0, y0-pad), min(img.width, x1+pad), min(img.height, y1+pad)))

def clean_alpha(img, min_frac=0.02):
    """keep only the biggest blob of the alpha mask and drop thin slivers (leftover shadow/label edges)"""
    a = np.asarray(img).copy()
    m = a[...,3] > 40
    m = ndi.binary_opening(m, iterations=2)
    lab, n = ndi.label(m)
    if n > 1:
        sizes = ndi.sum(m, lab, range(1, n+1))
        m = lab == (1 + int(np.argmax(sizes)))
    m = ndi.binary_dilation(m, iterations=3) & (a[...,3] > 0)
    a[...,3] = np.where(m, a[...,3], 0)
    return trim(Image.fromarray(a, 'RGBA'))



CELLS_10 = {
 'happy':(0,170,300,538), 'angry':(262,170,570,538), 'sad':(540,170,812,538), 'excited':(790,170,1070,538), 'shy':(1065,170,1312,538),
 'surprised':(0,590,300,950), 'sleepy':(280,590,590,950), 'thinking':(556,590,820,950), 'pouty':(800,590,1072,950), 'love':(1035,590,1312,950),
}
NAMES_25 = ['happy','laughing','angry','sad','excited','shy','surprised','sleepy','thinking','pouty',
            'love','kiss','wink','embarrassed','proud','scared','tired','hurt','cool','scream',
            'cheerful','hungry','confused','begging','goodbye']
COL_X = [137, 383, 651, 903, 1149]       # column centres on the 25-sheet
ROW_LABEL_Y = [334, 546, 745, 935, 1114] # centre of each row's name-pill

def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    s10, s25 = sys.argv[1], sys.argv[2]
    out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'assets', 'leon')
    os.makedirs(out, exist_ok=True)

    # ---------- 10 clean full-body sprites, bottom-centre aligned on one canvas so swapping never jumps
    im1 = Image.open(s10).convert('RGB')
    body = {}
    for k, b in CELLS_10.items():
        m, a = segment(im1.crop(b))
        body[k] = clean_alpha(to_rgba(a, m))
    CW = max(i.width for i in body.values()) + 8
    CH = max(i.height for i in body.values()) + 8
    for k, img in body.items():
        c = Image.new('RGBA', (CW, CH), (0, 0, 0, 0))
        c.alpha_composite(img, ((CW - img.width) // 2, CH - img.height - 4))
        c.save(os.path.join(out, f'body_{k}.png'), optimize=True)

    # ---------- 25 emote busts (the name-pill covers the torso, so keep head+chest and fade the cut)
    im2 = Image.open(s25).convert('RGB')
    arr = np.asarray(im2).copy()
    for ly in ROW_LABEL_Y:                       # paint the pills out so they never touch a dino
        arr[ly-19:ly+19, :, :] = np.array([205, 242, 232], np.uint8)
    im2p = Image.fromarray(arr)
    a = np.asarray(im2).astype(np.int32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mx = a.max(-1); mn = a.min(-1)
    sat = (mx - mn) / np.maximum(mx, 1)
    green_all = (g >= r) & (g >= b) & (sat > 0.5) & (mx > 140) & ((b - r) > 55)
    for r_ in range(5):
        for c_ in range(5):
            name = NAMES_25[r_ * 5 + c_]
            cx, ly = COL_X[c_], ROW_LABEL_Y[r_]
            wy0, wy1 = max(0, ly - 215), ly - 18
            wx0, wx1 = max(0, cx - 165), min(im2.width, cx + 165)
            gm = np.zeros_like(green_all); gm[wy0:wy1, wx0:wx1] = green_all[wy0:wy1, wx0:wx1]
            gm = ndi.binary_opening(gm, iterations=1)
            lab, n = ndi.label(ndi.binary_dilation(gm, iterations=10))
            best = 1 + int(np.argmax(ndi.sum(gm, lab, range(1, n + 1))))
            ys, xs = np.where((lab == best) & gm)
            box = (max(0, xs.min() - 42), max(0, ys.min() - 34), min(im2.width, xs.max() + 42), ly - 19)
            gsel = ((lab == best) & gm)[box[1]:box[3], box[0]:box[2]]
            mask = aa = None
            for th_, gr_ in [(95, 2), (115, 2), (115, 3), (135, 3), (135, 4), (150, 4), (150, 5)]:
                res = segment(im2p.crop(box), thresh=th_, grow=gr_, close_bottom=True)
                if res is None: continue
                mask, aa = res
                if (mask & gsel).sum() / max(1, gsel.sum()) >= 0.92: break
            img = clean_alpha(to_rgba(aa, mask))
            arr2 = np.asarray(img).copy().astype(np.float32)
            h = arr2.shape[0]; f0 = int(h * 0.80)
            ramp = np.ones(h, np.float32); ramp[f0:] = np.linspace(1, 0.0, h - f0)
            arr2[..., 3] *= ramp[:, None]
            Image.fromarray(arr2.astype(np.uint8), 'RGBA').save(os.path.join(out, f'emote_{name}.png'), optimize=True)
    print('wrote 10 body + 25 emote sprites to', os.path.abspath(out))

if __name__ == '__main__':
    main()
